import { useState, useEffect, useMemo } from "react";

// ─── Data ────────────────────────────────────────────────────────────────────
let PLATFORMS = [
  { id:"netflix",     name:"Netflix",         color:"#E50914", icon:"N",  hasProfiles:true  },
  { id:"disney",      name:"Disney+",         color:"#113CCF", icon:"D+", hasProfiles:true  },
  { id:"hbo",         name:"Max",             color:"#5822B4", icon:"M",  hasProfiles:true  },
  { id:"amazon",      name:"Prime Video",     color:"#00A8E0", icon:"P",  hasProfiles:true  },
  { id:"spotify",     name:"Spotify",         color:"#1DB954", icon:"S",  hasProfiles:false },
  { id:"apple",       name:"Apple TV+",       color:"#888888", icon:"A",  hasProfiles:true  },
  { id:"paramount",   name:"Paramount+",      color:"#0064FF", icon:"P+", hasProfiles:true  },
  { id:"crunchyroll", name:"Crunchyroll",     color:"#F47521", icon:"CR", hasProfiles:true  },
  { id:"youtube",     name:"YouTube Premium", color:"#FF0000", icon:"YT", hasProfiles:false },
  { id:"otro",        name:"Otro",            color:"#8B8B8B", icon:"?",  hasProfiles:true  },
];
const TAGS = [
  { id:"vip",     label:"VIP",     color:"#ffd60a", bg:"rgba(255,214,10,.15)"  },
  { id:"nuevo",   label:"Nuevo",   color:"#30d158", bg:"rgba(48,209,88,.15)"   },
  { id:"moroso",  label:"Moroso",  color:"#ff2d55", bg:"rgba(255,45,85,.15)"   },
  { id:"regular", label:"Regular", color:"#7c7cff", bg:"rgba(124,124,255,.15)" },
  { id:"promo",   label:"Promo",   color:"#ff9f0a", bg:"rgba(255,159,10,.15)"  },
];
const CURRENCIES = ["USD","EUR","MXN","ARS","COP","PEN","CLP","BRL"];
const EXPENSE_CATS = ["Cuenta","Herramienta","Suscripción propia","Marketing","Otro"];
const STORAGE_KEY = "streamtrack:v7";

const NAV_ITEMS = [
  { id:"dashboard",    icon:"📊", label:"Panel"         },
  { id:"ventas",       icon:"📋", label:"Ventas"         },
  { id:"clientes",     icon:"👥", label:"Clientes"       },
  { id:"pagos",        icon:"💳", label:"Pagos"          },
  { id:"recordatorios",icon:"🔔", label:"Recordatorios"  },
  { id:"ia",           icon:"🤖", label:"IA Mensajes"    },
  { id:"plats",        icon:"🎬", label:"Plataformas"    },
  { id:"gastos",       icon:"💸", label:"Gastos"         },
  { id:"wapp",         icon:"💬", label:"WhatsApp"       },
  { id:"plantillas",   icon:"📄", label:"Plantillas"     },
  { id:"config",       icon:"⚙️", label:"Configuración" },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────
const getDaysLeft=(d)=>{const t=new Date();t.setHours(0,0,0,0);const e=new Date(d);e.setHours(0,0,0,0);return Math.ceil((e-t)/86400000);};
const sem=(days)=>{
  if(days<0)  return{label:"Vencido", dot:"#ff2d55",bg:"rgba(255,45,85,.13)"};
  if(days<=3) return{label:"Crítico", dot:"#ff2d55",bg:"rgba(255,45,85,.13)"};
  if(days<=7) return{label:"Próximo", dot:"#ff9f0a",bg:"rgba(255,159,10,.13)"};
  if(days<=15)return{label:"Atención",dot:"#ffd60a",bg:"rgba(255,214,10,.13)"};
  return           {label:"Activo",  dot:"#30d158",bg:"rgba(48,209,88,.13)"};
};
const fmtDate=(s)=>s?new Date(s+"T00:00:00").toLocaleDateString("es-ES",{day:"2-digit",month:"short",year:"numeric"}):"—";
const fmtShort=(s)=>s?new Date(s+"T00:00:00").toLocaleDateString("es-ES",{day:"2-digit",month:"short"}):"—";
const genId=()=>Date.now().toString(36)+Math.random().toString(36).slice(2);
const platOf=(id,extra=[])=>[...PLATFORMS,...extra].find(p=>p.id===id)||PLATFORMS[PLATFORMS.length-1];
const tagOf=(id)=>TAGS.find(t=>t.id===id)||null;
const addDays=(s,n)=>{const d=new Date(s+"T00:00:00");d.setDate(d.getDate()+n);return d.toISOString().slice(0,10);};
const emptyProfile=()=>({id:genId(),nombre:"",monto:"",moneda:"USD",fechaVence:"",tag:"regular"});
const emptyForm={cliente:"",plataforma:"netflix",correo:"",contrasena:"",telefono:"",monto:"",moneda:"USD",fechaInicio:new Date().toISOString().slice(0,10),fechaVence:"",notas:"",periodoDias:30,tag:"regular",perfiles:[],usarPerfiles:false};
const emptyGasto={descripcion:"",categoria:"Cuenta",monto:"",moneda:"USD",fecha:new Date().toISOString().slice(0,10),notas:""};

const DEFAULT_TEMPLATES = [
  { id:"t1", nombre:"Bienvenida",          texto:"¡Hola {{cliente}}! 👋\nTe confirmamos tu acceso a *{{plataforma}}*.\n\n📧 Correo: {{correo}}\n🔑 Contraseña: {{contrasena}}\n📅 Vence: {{fechaVence}}\n\n¡Gracias por tu confianza! 🙌" },
  { id:"t2", nombre:"Vencimiento próximo", texto:"¡Hola {{cliente}}! ⏰\nTu cuenta de *{{plataforma}}* vence el *{{fechaVence}}*.\n\n💰 Renueva por solo ${{monto}} {{moneda}}\n\n¿Deseas renovar? Escríbenos 😊" },
  { id:"t3", nombre:"Cuenta vencida",      texto:"¡Hola {{cliente}}! 🔴\nTu cuenta de *{{plataforma}}* ya venció.\n\nRenueva ahora para no perder acceso.\n📞 Estamos para ayudarte." },
];

const THEMES = [
  { id:"purple", label:"Morado", accent:"#7c7cff", accent2:"#9b3dff", grad:"linear-gradient(135deg,#5c5cff,#9b3dff)" },
  { id:"blue",   label:"Azul",   accent:"#3b82f6", accent2:"#2563eb", grad:"linear-gradient(135deg,#3b82f6,#1d4ed8)" },
  { id:"green",  label:"Verde",  accent:"#10b981", accent2:"#059669", grad:"linear-gradient(135deg,#10b981,#059669)" },
  { id:"pink",   label:"Rosa",   accent:"#ec4899", accent2:"#db2777", grad:"linear-gradient(135deg,#ec4899,#be185d)" },
  { id:"orange", label:"Naranja",accent:"#f97316", accent2:"#ea580c", grad:"linear-gradient(135deg,#f97316,#c2410c)" },
  { id:"teal",   label:"Teal",   accent:"#14b8a6", accent2:"#0d9488", grad:"linear-gradient(135deg,#14b8a6,#0f766e)" },
];

const DARK_PALETTE = {
  bg:"#090912", sidebar:"#0c0c1c", card:"#10101e",
  border:"#1c1c30", border2:"#161628", input:"#181828",
  text:"#e2e2f0", textMuted:"#44445a", textSub:"#8888aa",
  overlay:"rgba(0,0,0,.82)",
};
const LIGHT_PALETTE = {
  bg:"#f0f2f8", sidebar:"#ffffff", card:"#ffffff",
  border:"#e2e5f0", border2:"#eaedf5", input:"#f5f7fc",
  text:"#0f1117", textMuted:"#6b7280", textSub:"#9ca3af",
  overlay:"rgba(0,0,0,.5)",
};

const DEFAULT_CONFIG = { negocio:"Mi Negocio", monedaDefault:"USD", alertaDias:7, telefono:"", darkMode:true, themeId:"orange" };

// ─── CSS ─────────────────────────────────────────────────────────────────────
const CSS=`
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;500;700;800&family=DM+Mono:wght@400;500&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:#0a0a16}::-webkit-scrollbar-thumb{background:#252540;border-radius:3px}
input,select,textarea,button{font-family:inherit}
.ifield{background:var(--input);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:14px;width:100%;outline:none;transition:border .2s}
.ifield:focus{border-color:var(--accent)}
.btn{cursor:pointer;border:none;border-radius:10px;font-weight:700;transition:all .17s}
.btn:active{transform:scale(.96)}
.card{background:var(--card);border:1px solid var(--border);border-radius:14px}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(7px);z-index:300;display:flex;align-items:center;justify-content:center}
.pulse{animation:pulse 1.8s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
.tag-chip{display:inline-flex;align-items:center;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700}
.row-item{padding:13px 18px;border-bottom:1px solid #161628;transition:background .14s;cursor:pointer}
.row-item:hover{background:#131326}
.toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1a2a1a;border:1px solid #30d158;border-radius:12px;padding:13px 20px;z-index:999;display:flex;align-items:center;gap:10px;animation:slideUp .3s ease;box-shadow:0 8px 32px rgba(0,0,0,.5);white-space:nowrap}
@keyframes slideUp{from{opacity:0;transform:translateX(-50%) translateY(16px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
.nav-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:10px;cursor:pointer;transition:all .18s;border:none;background:none;color:#55557a;width:100%;text-align:left;font-size:13px;font-weight:600}
.nav-item:hover{background:#14142a;color:#c0c0e0}
.nav-item.active{background:#5c5cff22;color:#7c7cff;border:1px solid #7c7cff33}
`;

export default function App() {
  const [data,     setData]     = useState({ventas:[],pagos:[],recordatorios:[],gastos:[],plantillas:DEFAULT_TEMPLATES,config:DEFAULT_CONFIG,customPlats:[]});
  const [loaded,   setLoaded]   = useState(false);
  const [saving,   setSaving]   = useState(false);
  const [saveOk,   setSaveOk]   = useState(false);
  const [vista,    setVista]    = useState("dashboard");
  const [sidebar,  setSidebar]  = useState(true); // collapsed on mobile
  const [toast,    setToast]    = useState(null);

  // Form states
  const [showForm,   setShowForm]   = useState(false);
  const [form,       setForm]       = useState(emptyForm);
  const [editId,     setEditId]     = useState(null);
  const [showPass,   setShowPass]   = useState({});
  const [expanded,   setExpanded]   = useState(null);
  const [delId,      setDelId]      = useState(null);
  const [renewId,    setRenewId]    = useState(null);
  const [selCliente, setSelCliente] = useState(null);
  const [busqCli,    setBusqCli]    = useState("");
  const [filtroTagCli,setFiltroTagCli]=useState("todos");
  const [renewDays,  setRenewDays]  = useState(30);
  const [showHist,   setShowHist]   = useState(null);
  const [showAlerts, setShowAlerts] = useState(false);
  // Plataformas personalizadas
  const [showPlat,   setShowPlat]   = useState(false);
  const [platForm,   setPlatForm]   = useState({name:"",icon:"",color:"#7c7cff",hasProfiles:true});
  const [editPlatId, setEditPlatId] = useState(null);
  // Pagos
  const [showPago,   setShowPago]   = useState(false);
  const [pagoForm,   setPagoForm]   = useState({ventaId:"",monto:"",moneda:"USD",estado:"pendiente",fecha:new Date().toISOString().slice(0,10),notas:""});
  const [editPagoId, setEditPagoId] = useState(null);
  // Recordatorios
  const [showRec,    setShowRec]    = useState(false);
  const [recForm,    setRecForm]    = useState({ventaId:"",diasAntes:3,mensaje:"",activo:true});
  const [editRecId,  setEditRecId]  = useState(null);
  // IA
  const [iaVenta,    setIaVenta]    = useState(null);
  const [iaTipo,     setIaTipo]     = useState("renovacion");
  const [iaMsg,      setIaMsg]      = useState("");
  const [iaLoading,  setIaLoading]  = useState(false);
  const [iaError,    setIaError]    = useState("");

  // Gastos
  const [showGasto,  setShowGasto]  = useState(false);
  const [gastoForm,  setGastoForm]  = useState(emptyGasto);
  const [editGastoId,setEditGastoId]= useState(null);

  // WhatsApp
  const [wappVenta,  setWappVenta]  = useState(null);
  const [wappTpl,    setWappTpl]    = useState(null);
  const [wappMsg,    setWappMsg]    = useState("");
  const [wappPhone,  setWappPhone]  = useState("");
  const [wappCopied, setWappCopied] = useState(false);

  // Plantillas
  const [editTpl,    setEditTpl]    = useState(null);
  const [tplForm,    setTplForm]    = useState({nombre:"",texto:""});

  // Filtros ventas
  const [busqueda,   setBusqueda]   = useState("");
  const [filtroPlat, setFiltroPlat] = useState("todas");
  const [filtroTag,  setFiltroTag]  = useState("todos");
  const [tabVentas,  setTabVentas]  = useState("todas");

  const ventas         = data.ventas;
  const customPlats    = data.customPlats||[];
  const allPlatforms   = [...PLATFORMS.filter(p=>p.id!=="otro"), ...customPlats, PLATFORMS[PLATFORMS.length-1]];
  const pagos          = data.pagos||[];
  const recordatorios  = data.recordatorios||[];
  const gastos         = data.gastos;
  const plantillas= data.plantillas;
  const config    = data.config;
  const darkMode  = config.darkMode !== false;
  const themeId   = config.themeId || "purple";
  const theme     = THEMES.find(t=>t.id===themeId)||THEMES[0];
  const P         = darkMode ? DARK_PALETTE : LIGHT_PALETTE;

  // ── Storage ──────────────────────────────────────────────────────────────
  useEffect(()=>{
    async function load(){
      try{
        const r=await window.storage.get(STORAGE_KEY);
        if(r?.value){
          const d=JSON.parse(r.value);
          setData({
            ventas:        Array.isArray(d.ventas)?d.ventas:[],
            pagos:         Array.isArray(d.pagos)?d.pagos:[],
            recordatorios: Array.isArray(d.recordatorios)?d.recordatorios:[],
            gastos:        Array.isArray(d.gastos)?d.gastos:[],
            plantillas:    Array.isArray(d.plantillas)&&d.plantillas.length?d.plantillas:DEFAULT_TEMPLATES,
            config:        d.config||DEFAULT_CONFIG,
            customPlats:   Array.isArray(d.customPlats)?d.customPlats:[],
          });
        }
      }catch{}
      setLoaded(true);
    }
    load();
  },[]);

  async function save(nd){
    setSaving(true);
    try{ await window.storage.set(STORAGE_KEY,JSON.stringify(nd)); setSaveOk(true); setTimeout(()=>setSaveOk(false),2000); }catch{}
    setSaving(false);
  }
  const mutate=(patch)=>{ const nd={...data,...patch}; setData(nd); save(nd); };

  // ── Pagos CRUD ────────────────────────────────────────────────────────────
  function handleSavePago(){
    if(!pagoForm.ventaId||!pagoForm.monto) return;
    const p={...pagoForm,id:editPagoId||genId()};
    const np=editPagoId?pagos.map(x=>x.id===editPagoId?p:x):[...pagos,p];
    mutate({pagos:np}); setEditPagoId(null); setPagoForm({ventaId:"",monto:"",moneda:"USD",estado:"pendiente",fecha:new Date().toISOString().slice(0,10),notas:""}); setShowPago(false);
    showToast("Pago guardado ✓");
  }
  function handleDeletePago(id){ mutate({pagos:pagos.filter(p=>p.id!==id)}); showToast("Pago eliminado","#ff2d55"); }
  function handlePagoEstado(id,estado){
    mutate({pagos:pagos.map(p=>p.id===id?{...p,estado}:p)});
    showToast(estado==="pagado"?"Marcado como pagado ✓":estado==="parcial"?"Marcado como parcial":"Marcado como pendiente");
  }

  // ── Recordatorios CRUD ────────────────────────────────────────────────────
  function handleSaveRec(){
    if(!recForm.ventaId) return;
    const r={...recForm,id:editRecId||genId()};
    const nr=editRecId?recordatorios.map(x=>x.id===editRecId?r:x):[...recordatorios,r];
    mutate({recordatorios:nr}); setEditRecId(null); setRecForm({ventaId:"",diasAntes:3,mensaje:"",activo:true}); setShowRec(false);
    showToast("Recordatorio guardado ✓");
  }
  function handleDeleteRec(id){ mutate({recordatorios:recordatorios.filter(r=>r.id!==id)}); showToast("Recordatorio eliminado","#ff2d55"); }
  function handleToggleRec(id){ mutate({recordatorios:recordatorios.map(r=>r.id===id?{...r,activo:!r.activo}:r)}); }

  // ── Plataformas personalizadas CRUD ─────────────────────────────────────────
  function handleSavePlat(){
    if(!platForm.name.trim()) return;
    const icon = platForm.icon || platForm.name.slice(0,2).toUpperCase();
    const id = editPlatId || ("custom_"+genId());
    const p = {...platForm, id, icon, hasProfiles:platForm.hasProfiles!==false};
    const np = editPlatId ? customPlats.map(x=>x.id===editPlatId?p:x) : [...customPlats, p];
    mutate({customPlats:np});
    setEditPlatId(null); setPlatForm({name:"",icon:"",color:"#7c7cff",hasProfiles:true}); setShowPlat(false);
    showToast("Plataforma guardada ✓");
  }
  function handleDeletePlat(id){
    mutate({customPlats:customPlats.filter(p=>p.id!==id)});
    showToast("Plataforma eliminada","#ff2d55");
  }

  // ── IA Mensajes ───────────────────────────────────────────────────────────
  async function handleGenerarIA(){
    if(!iaVenta) return;
    setIaLoading(true); setIaError(""); setIaMsg("");
    const plt=platOf(iaVenta.plataforma);
    const days=getMinDays(iaVenta);
    const tipos={
      renovacion:"para pedirle que renueve su servicio que vence pronto",
      bienvenida:"de bienvenida para entregarle sus credenciales de acceso",
      cobro:"para recordarle un pago pendiente de forma amable",
      reactivacion:"para invitarle a volver después de que su cuenta venció",
    };
    const prompt=`Redacta un mensaje de WhatsApp breve y amigable en español ${tipos[iaTipo]}.
Datos del cliente:
- Nombre: ${iaVenta.cliente}
- Plataforma: ${plt.name}
- Correo: ${iaVenta.correo||"no registrado"}
- Vencimiento: ${fmtDate(iaVenta.fechaVence)} (${days<0?"ya venció hace "+Math.abs(days)+" días":days===0?"vence hoy":"faltan "+days+" días"})
- Monto: ${iaVenta.monto?" $"+iaVenta.monto+" "+iaVenta.moneda:"no especificado"}
- Etiqueta: ${iaVenta.tag||"regular"}
Usa emojis, sé natural y persuasivo. Máximo 5 líneas. No uses placeholders, usa los datos reales.`;
    try {
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:prompt}]})
      });
      const d=await res.json();
      const txt=d.content?.find(x=>x.type==="text")?.text||"";
      setIaMsg(txt);
    } catch(e){ setIaError("Error al generar. Intenta de nuevo."); }
    setIaLoading(false);
  }
  const showToast=(msg,color="#30d158")=>{ setToast({msg,color}); setTimeout(()=>setToast(null),3000); };

  // ── Ventas CRUD ───────────────────────────────────────────────────────────
  function handleSaveVenta(){
    if(!form.cliente.trim()||(!form.usarPerfiles&&!form.fechaVence)) return;
    const v={...form,id:editId||genId(),historia:editId?(ventas.find(x=>x.id===editId)?.historia||[]):[]};
    const nv=editId?ventas.map(x=>x.id===editId?v:x):[...ventas,v];
    mutate({ventas:nv}); setEditId(null); setForm(emptyForm); setShowForm(false);
    showToast(editId?"Cuenta actualizada ✓":"Cuenta registrada ✓");
  }
  function handleDeleteVenta(id){ mutate({ventas:ventas.filter(v=>v.id!==id)}); setDelId(null); showToast("Cuenta eliminada","#ff2d55"); }
  function handleEditVenta(v){ setForm({...v,periodoDias:v.periodoDias||30,perfiles:v.perfiles||[],usarPerfiles:v.usarPerfiles||false}); setEditId(v.id); setShowForm(true); }

  function handleRenew(id,days){
    const v=ventas.find(x=>x.id===id); if(!v)return;
    const base=getDaysLeft(v.fechaVence)<0?new Date().toISOString().slice(0,10):v.fechaVence;
    const nf=addDays(base,days);
    const h={id:genId(),fecha:new Date().toISOString().slice(0,10),fechaAnterior:v.fechaVence,fechaNueva:nf,dias:days,monto:v.monto,moneda:v.moneda};
    mutate({ventas:ventas.map(x=>x.id===id?{...x,fechaVence:nf,fechaInicio:new Date().toISOString().slice(0,10),historia:[...(x.historia||[]),h]}:x)});
    setRenewId(null); showToast(`${v.cliente} renovado ${days}d ✓`);
  }

  // ── Gastos CRUD ───────────────────────────────────────────────────────────
  function handleSaveGasto(){
    if(!gastoForm.descripcion.trim()||!gastoForm.monto) return;
    const g={...gastoForm,id:editGastoId||genId()};
    const ng=editGastoId?gastos.map(x=>x.id===editGastoId?g:x):[...gastos,g];
    mutate({gastos:ng}); setEditGastoId(null); setGastoForm(emptyGasto); setShowGasto(false);
    showToast("Gasto guardado ✓");
  }
  function handleDeleteGasto(id){ mutate({gastos:gastos.filter(g=>g.id!==id)}); showToast("Gasto eliminado","#ff2d55"); }

  // ── WhatsApp ──────────────────────────────────────────────────────────────
  function buildWappMsg(venta,tplTexto){
    const plt=platOf(venta.plataforma);
    return tplTexto
      .replace(/{{cliente}}/g,venta.cliente||"")
      .replace(/{{plataforma}}/g,plt.name||"")
      .replace(/{{correo}}/g,venta.correo||"")
      .replace(/{{contrasena}}/g,venta.contrasena||"")
      .replace(/{{fechaVence}}/g,fmtDate(venta.fechaVence)||"")
      .replace(/{{monto}}/g,venta.monto||"")
      .replace(/{{moneda}}/g,venta.moneda||"")
      .replace(/{{telefono}}/g,venta.telefono||"");
  }
  function openWapp(venta,tpl){
    const msg=buildWappMsg(venta,tpl.texto);
    setWappVenta(venta); setWappTpl(tpl); setWappMsg(msg);
    setWappPhone(venta.telefono||""); setWappCopied(false);
  }
  function sendWapp(){
    const phone=wappPhone.replace(/\D/g,"");
    const url=`https://wa.me/${phone}?text=${encodeURIComponent(wappMsg)}`;
    window.open(url,"_blank");
  }
  function copyWapp(){ navigator.clipboard.writeText(wappMsg).then(()=>{ setWappCopied(true); setTimeout(()=>setWappCopied(false),2000); }); }

  // ── Plantillas ────────────────────────────────────────────────────────────
  function handleSaveTpl(){
    if(!tplForm.nombre.trim()||!tplForm.texto.trim())return;
    const t={...tplForm,id:editTpl||genId()};
    const np=editTpl?plantillas.map(x=>x.id===editTpl?t:x):[...plantillas,t];
    mutate({plantillas:np}); setEditTpl(null); setTplForm({nombre:"",texto:""}); showToast("Plantilla guardada ✓");
  }
  function handleDeleteTpl(id){ mutate({plantillas:plantillas.filter(t=>t.id!==id)}); showToast("Plantilla eliminada","#ff2d55"); }

  // ── Derived ───────────────────────────────────────────────────────────────
  const getMinDays=v=>v.usarPerfiles&&v.perfiles?.length?Math.min(...v.perfiles.map(p=>getDaysLeft(p.fechaVence))):getDaysLeft(v.fechaVence);
  const alerts=useMemo(()=>ventas.filter(v=>getMinDays(v)<=config.alertaDias).sort((a,b)=>getMinDays(a)-getMinDays(b)),[ventas,config]);
  const totalAlertas=alerts.length;

  const ventasFiltradas=useMemo(()=>{
    let r=ventas;
    if(busqueda){const q=busqueda.toLowerCase();r=r.filter(v=>v.cliente.toLowerCase().includes(q)||platOf(v.plataforma,customPlats).name.toLowerCase().includes(q)||(v.correo||"").toLowerCase().includes(q)||(v.telefono||"").includes(q));}
    if(filtroPlat!=="todas")r=r.filter(v=>v.plataforma===filtroPlat);
    if(filtroTag!=="todos")r=r.filter(v=>v.tag===filtroTag);
    if(tabVentas==="vencidos")r=r.filter(v=>getMinDays(v)<0);
    if(tabVentas==="proximos")r=r.filter(v=>{const d=getMinDays(v);return d>=0&&d<=7;});
    if(tabVentas==="activos") r=r.filter(v=>getMinDays(v)>7);
    return r.sort((a,b)=>getMinDays(a)-getMinDays(b));
  },[ventas,busqueda,filtroPlat,filtroTag,tabVentas]);

  const stats=useMemo(()=>{
    const ingresos=ventas.reduce((a,v)=>{
      if(v.usarPerfiles)return a+(v.perfiles||[]).reduce((s,p)=>s+(parseFloat(p.monto)||0),0);
      return a+(parseFloat(v.monto)||0);
    },0);
    const totalGastos=gastos.reduce((a,g)=>a+(parseFloat(g.monto)||0),0);
    return{
      total:ventas.length,
      activos:ventas.filter(v=>getMinDays(v)>7).length,
      proximos:ventas.filter(v=>{const d=getMinDays(v);return d>=0&&d<=7;}).length,
      vencidos:ventas.filter(v=>getMinDays(v)<0).length,
      ingresos, gastos:totalGastos, neto:ingresos-totalGastos,
      perfiles:ventas.reduce((a,v)=>a+(v.usarPerfiles?(v.perfiles||[]).length:0),0),
    };
  },[ventas,gastos]);

  const porPlat=useMemo(()=>{
    const m={};
    ventas.forEach(v=>{if(!m[v.plataforma])m[v.plataforma]=[];m[v.plataforma].push(v);});
    return Object.entries(m).sort((a,b)=>b[1].length-a[1].length);
  },[ventas]);

  if(!loaded) return(
    <div style={{fontFamily:"'DM Sans',sans-serif",background:P.bg,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",color:P.text}}>
      <div style={{textAlign:"center"}}><div style={{fontSize:40,marginBottom:12}}>▶</div><div style={{color:"#44445a"}}>Cargando StreamTrack Pro…</div></div>
    </div>
  );

  // ── Sub-components ────────────────────────────────────────────────────────
  const TagChip=({tagId,small})=>{const t=tagOf(tagId);if(!t)return null;return<span className="tag-chip" style={{background:t.bg,color:t.color,fontSize:small?10:11}}>{t.label}</span>;};
  const StatusBadge=({days})=>{const s=sem(days);return(<div style={{display:"inline-flex",alignItems:"center",gap:5,background:s.bg,padding:"4px 9px",borderRadius:20,flexShrink:0}}><div style={{width:6,height:6,borderRadius:"50%",background:s.dot}} className={days<=3&&days>=0?"pulse":""}/><span style={{fontSize:11,fontWeight:700,color:s.dot}}>{s.label}</span><span style={{fontSize:10,color:s.dot+"99"}}>{days<0?`${Math.abs(days)}d`:days===0?"Hoy":`${days}d`}</span></div>);};

  // ── Layout ────────────────────────────────────────────────────────────────
  return(
    <div style={{fontFamily:"'DM Sans','Segoe UI',sans-serif",background:P.bg,minHeight:"100vh",color:P.text,display:"flex"}}>
    <style>{CSS+`
:root{
  --card:${P.card};--border:${P.border};--input:${P.input};
  --text:${P.text};--accent:${theme.accent};
}
.nav-item.active{background:${theme.accent}22;color:${theme.accent};border:1px solid ${theme.accent}33 !important}
`}</style>

    {/* ══ SIDEBAR ══ */}
    <div style={{width:sidebar?220:64,flexShrink:0,background:P.sidebar,borderRight:`1px solid ${P.border2}`,height:"100vh",position:"sticky",top:0,display:"flex",flexDirection:"column",transition:"width .25s",overflow:"hidden",zIndex:40}}>
      {/* Logo */}
      <div style={{padding:"16px 14px",borderBottom:`1px solid ${P.border2}`,display:"flex",alignItems:"center",gap:10}}>
        <div style={{width:34,height:34,background:"linear-gradient(135deg,#5c5cff,#9b3dff)",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>▶</div>
        {sidebar&&<div><div style={{fontWeight:800,fontSize:14,letterSpacing:"-.3px"}}>StreamTrack</div><div style={{fontSize:9,background:"linear-gradient(135deg,#5c5cff,#9b3dff)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",fontWeight:800}}>PRO</div></div>}
      </div>

      {/* Nav */}
      <nav style={{flex:1,padding:"10px 8px",overflowY:"auto"}}>
        {NAV_ITEMS.map(item=>(
          <button key={item.id} className={`nav-item${vista===item.id?" active":""}`} onClick={()=>setVista(item.id)} title={item.label}>
            <span style={{fontSize:18,flexShrink:0}}>{item.icon}</span>
            {sidebar&&<span>{item.label}</span>}
            {item.id==="dashboard"&&totalAlertas>0&&sidebar&&(
              <span style={{marginLeft:"auto",background:"#ff2d55",color:"#fff",borderRadius:"50%",width:18,height:18,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800}} className="pulse">{totalAlertas}</span>
            )}
            {item.id==="pagos"&&pagos.filter(p=>p.estado==="pendiente").length>0&&sidebar&&(
              <span style={{marginLeft:"auto",background:"#ff9f0a",color:"#fff",borderRadius:10,padding:"1px 7px",fontSize:10,fontWeight:800}}>{pagos.filter(p=>p.estado==="pendiente").length}</span>
            )}
            {item.id==="recordatorios"&&recordatorios.filter(r=>{if(!r.activo)return false;const v=ventas.find(x=>x.id===r.ventaId);if(!v)return false;return getDaysLeft(v.fechaVence)<=r.diasAntes&&getDaysLeft(v.fechaVence)>=0;}).length>0&&sidebar&&(
              <span style={{marginLeft:"auto",background:theme.accent,color:"#fff",borderRadius:10,padding:"1px 7px",fontSize:10,fontWeight:800}} className="pulse">!</span>
            )}
            {item.id==="dashboard"&&totalAlertas>0&&!sidebar&&(
              <div style={{position:"absolute",top:6,right:6,width:8,height:8,borderRadius:"50%",background:"#ff2d55"}} className="pulse"/>
            )}
          </button>
        ))}
      </nav>

      {/* Save + collapse */}
      <div style={{padding:"10px 8px",borderTop:"1px solid #161628"}}>
        <div style={{display:"flex",alignItems:"center",gap:6,padding:"8px 10px",borderRadius:8,background:darkMode?"#12122a":"#f0f2f8",marginBottom:6}}>
          <div style={{width:7,height:7,borderRadius:"50%",background:saving?"#ffd60a":saveOk?"#30d158":theme.accent,flexShrink:0}} className={saving?"pulse":""}/>
          {sidebar&&<span style={{fontSize:11,color:"#8888aa"}}>{saving?"Guardando…":saveOk?"Guardado ✓":"☁️ Auto-sync"}</span>}
        </div>
        <button onClick={()=>setSidebar(!sidebar)} style={{width:"100%",padding:"7px 10px",background:darkMode?"#181828":"#e8eaf0",border:"none",borderRadius:8,cursor:"pointer",color:P.textMuted,fontSize:13,display:"flex",alignItems:"center",gap:8,justifyContent:sidebar?"flex-start":"center"}}>
          <span>{sidebar?"◀":"▶"}</span>
          {sidebar&&<span style={{fontSize:12}}>Colapsar</span>}
        </button>
      </div>
    </div>

    {/* ══ MAIN ══ */}
    <div style={{flex:1,minWidth:0,height:"100vh",overflowY:"auto"}}>

      {/* Top bar */}
      <div style={{background:P.bg,borderBottom:`1px solid ${P.border2}`,padding:"0 20px",height:52,display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,zIndex:30}}>
        <div style={{fontWeight:700,fontSize:15,color:P.text}}>
          {NAV_ITEMS.find(n=>n.id===vista)?.icon} {NAV_ITEMS.find(n=>n.id===vista)?.label}
        </div>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          {totalAlertas>0&&(
            <button onClick={()=>setShowAlerts(true)} style={{position:"relative",background:darkMode?"#12122a":"#f0f2f8",border:`1px solid ${P.border2}`,borderRadius:8,padding:"6px 10px",cursor:"pointer",color:"#e2e2f0",display:"flex",alignItems:"center",gap:5,fontSize:13}}>
              🔔<div style={{position:"absolute",top:-4,right:-4,background:"#ff2d55",borderRadius:"50%",width:16,height:16,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800,color:"#fff",border:"2px solid #090912"}} className="pulse">{totalAlertas}</div>
            </button>
          )}
          {(vista==="dashboard"||vista==="ventas"||vista==="clientes")&&(
            <button className="btn" onClick={()=>{setForm(emptyForm);setEditId(null);setShowForm(true);}} style={{background:theme.grad,color:"#fff",padding:"7px 14px",fontSize:13}}>+ Nueva cuenta</button>
          )}
          {vista==="gastos"&&(
            <button className="btn" onClick={()=>{setGastoForm(emptyGasto);setEditGastoId(null);setShowGasto(true);}} style={{background:"linear-gradient(135deg,#ff2d55,#ff6b6b)",color:"#fff",padding:"7px 14px",fontSize:13}}>+ Gasto</button>
          )}
          {vista==="pagos"&&(
            <button className="btn" onClick={()=>{setPagoForm({ventaId:"",monto:"",moneda:"USD",estado:"pendiente",fecha:new Date().toISOString().slice(0,10),notas:""});setEditPagoId(null);setShowPago(true);}} style={{background:theme.grad,color:"#fff",padding:"7px 14px",fontSize:13}}>+ Pago</button>
          )}
          {vista==="recordatorios"&&(
            <button className="btn" onClick={()=>{setRecForm({ventaId:"",diasAntes:3,mensaje:"",activo:true});setEditRecId(null);setShowRec(true);}} style={{background:theme.grad,color:"#fff",padding:"7px 14px",fontSize:13}}>+ Recordatorio</button>
          )}
          {vista==="plantillas"&&(
            <button className="btn" onClick={()=>{setTplForm({nombre:"",texto:""});setEditTpl(null);}} style={{background:"linear-gradient(135deg,#5c5cff,#9b3dff)",color:"#fff",padding:"7px 14px",fontSize:13}}>+ Plantilla</button>
          )}
        </div>
      </div>

      <div style={{padding:"20px 18px",maxWidth:1100,margin:"0 auto"}}>

      {/* ════ DASHBOARD ════ */}
      {vista==="dashboard"&&(
        <div>
          {totalAlertas>0&&(
            <div onClick={()=>setShowAlerts(true)} style={{background:"linear-gradient(135deg,rgba(255,45,85,.12),rgba(255,159,10,.08))",border:"1px solid rgba(255,45,85,.3)",borderRadius:14,padding:"13px 18px",marginBottom:18,cursor:"pointer",display:"flex",alignItems:"center",gap:12}}>
              <span style={{fontSize:24}} className="pulse">🚨</span>
              <div style={{flex:1}}><div style={{fontWeight:700,fontSize:14,color:"#ff6b6b"}}>{totalAlertas} cuenta{totalAlertas!==1?"s":""} requiere{totalAlertas===1?"":"n"} atención</div><div style={{fontSize:12,color:"#666"}}>Toca para ver y renovar →</div></div>
              <span style={{color:"#ff6b6b",fontSize:18}}>›</span>
            </div>
          )}

          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))",gap:10,marginBottom:20}}>
            {[
              {l:"Cuentas",   v:stats.total,   ic:"📦",c:"#7c7cff"},
              {l:"Perfiles",  v:stats.perfiles,ic:"👤",c:"#a855f7"},
              {l:"Activas",   v:stats.activos, ic:"🟢",c:"#30d158"},
              {l:"Por Vencer",v:stats.proximos,ic:"🟡",c:"#ff9f0a"},
              {l:"Vencidas",  v:stats.vencidos,ic:"🔴",c:"#ff2d55"},
              {l:"Ingresos",  v:`$${stats.ingresos.toFixed(0)}`,ic:"💰",c:"#ffd60a"},
              {l:"Gastos",    v:`$${stats.gastos.toFixed(0)}`,ic:"💸",c:"#ff6b6b"},
              {l:"Neto",      v:`$${stats.neto.toFixed(0)}`,ic:"📈",c:stats.neto>=0?"#30d158":"#ff2d55"},
            ].map(s=>(
              <div key={s.l} className="card" style={{padding:14}}>
                <div style={{fontSize:18,marginBottom:4}}>{s.ic}</div>
                <div style={{fontSize:20,fontWeight:800,color:s.c}}>{s.v}</div>
                <div style={{fontSize:11,color:"#44445a",marginTop:2}}>{s.l}</div>
              </div>
            ))}
          </div>

          {/* Próximos */}
          <div className="card" style={{marginBottom:16}}>
            <div style={{padding:"12px 18px",borderBottom:"1px solid #161628",fontWeight:700,fontSize:14}}>⏰ Próximos a vencer (15 días)</div>
            {ventas.filter(v=>{const d=getMinDays(v);return d>=0&&d<=15;}).length===0
              ?<div style={{padding:22,color:"#44445a",textAlign:"center"}}>✅ Sin vencimientos próximos</div>
              :ventas.filter(v=>{const d=getMinDays(v);return d>=0&&d<=15;}).sort((a,b)=>getMinDays(a)-getMinDays(b)).map(v=>{
                const plt=platOf(v.plataforma,customPlats),days=getMinDays(v);
                return(
                  <div key={v.id} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 18px",borderBottom:"1px solid #161628"}}>
                    <div style={{width:32,height:32,background:plt.color+"22",border:`2px solid ${plt.color}`,borderRadius:7,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:plt.color,flexShrink:0}}>{plt.icon}</div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontWeight:600,fontSize:13}}>{v.cliente} <TagChip tagId={v.tag} small/></div>
                      <div style={{fontSize:11,color:"#44445a"}}>{plt.name} · {v.telefono||"sin tel"}</div>
                    </div>
                    <div style={{display:"flex",gap:7,alignItems:"center",flexShrink:0}}>
                      <StatusBadge days={days}/>
                      <button onClick={()=>{const t=plantillas.find(x=>x.id==="t2")||plantillas[0];openWapp(v,t);}} style={{background:"#1a3a1a",border:"1px solid #2a5a2a",borderRadius:7,padding:"4px 9px",cursor:"pointer",color:"#30d158",fontSize:12,fontWeight:700}}>💬</button>
                      <button onClick={()=>{setRenewId(v.id);setRenewDays(v.periodoDias||30);}} style={{background:"linear-gradient(135deg,#ff9f0a,#ff6b00)",border:"none",borderRadius:7,padding:"4px 9px",cursor:"pointer",color:"#fff",fontSize:12,fontWeight:700}}>🔄</button>
                    </div>
                  </div>
                );
              })}
          </div>

          {/* Resumen plataformas */}
          <div className="card">
            <div style={{padding:"12px 18px",borderBottom:"1px solid #161628",fontWeight:700,fontSize:14}}>🎬 Por Plataforma</div>
            {porPlat.length===0?<div style={{padding:22,color:"#44445a",textAlign:"center"}}>Sin datos</div>
              :porPlat.map(([pid,items])=>{
                const plt=platOf(pid,customPlats),tot=items.reduce((acc2,vv)=>{if(vv.usarPerfiles)return acc2+(vv.perfiles||[]).reduce((ss,pp)=>ss+(parseFloat(pp.monto)||0),0);return acc2+(parseFloat(vv.monto)||0);},0);
                const act=items.filter(v=>getMinDays(v)>=0).length,venc=items.length-act;
                return(
                  <div key={pid} style={{display:"flex",alignItems:"center",gap:10,padding:"11px 18px",borderBottom:"1px solid #161628"}}>
                    <div style={{width:34,height:34,background:plt.color+"22",border:`2px solid ${plt.color}`,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:plt.color,flexShrink:0}}>{plt.icon}</div>
                    <div style={{flex:1}}><div style={{fontWeight:600}}>{plt.name}</div><div style={{fontSize:11,color:"#44445a"}}>{items.length} cuenta{items.length!==1?"s":""}</div></div>
                    <div style={{display:"flex",gap:6}}>
                      <span style={{background:"rgba(48,209,88,.12)",color:"#30d158",padding:"2px 8px",borderRadius:20,fontSize:11,fontWeight:700}}>{act}✓</span>
                      {venc>0&&<span style={{background:"rgba(255,45,85,.12)",color:"#ff2d55",padding:"2px 8px",borderRadius:20,fontSize:11,fontWeight:700}}>{venc}✗</span>}
                      <span style={{fontSize:13,fontWeight:700,color:"#ffd60a"}}>${tot.toFixed(0)}</span>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ════ VENTAS ════ */}
      {vista==="ventas"&&(
        <div>
          <div style={{display:"flex",gap:8,marginBottom:14,flexWrap:"wrap"}}>
            <input className="ifield" placeholder="🔍 Buscar…" value={busqueda} onChange={e=>setBusqueda(e.target.value)} style={{maxWidth:180}}/>
            <select className="ifield" value={filtroPlat} onChange={e=>setFiltroPlat(e.target.value)} style={{maxWidth:150}}>
              <option value="todas">Todas</option>
              {allPlatforms.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <select className="ifield" value={filtroTag} onChange={e=>setFiltroTag(e.target.value)} style={{maxWidth:130}}>
              <option value="todos">Etiquetas</option>
              {TAGS.map(t=><option key={t.id} value={t.id}>{t.label}</option>)}
            </select>
            <div style={{display:"flex",gap:3,background:"#10101e",border:"1px solid #1c1c30",borderRadius:10,padding:4}}>
              {[["todas","Todas"],["activos","🟢"],["proximos","🟡"],["vencidos","🔴"]].map(([k,l])=>(
                <button key={k} onClick={()=>setTabVentas(k)} style={{padding:"5px 11px",borderRadius:7,fontSize:12,fontWeight:600,border:"none",cursor:"pointer",background:tabVentas===k?"#181838":"transparent",color:tabVentas===k?"#9898ff":"#44445a"}}>{l}</button>
              ))}
            </div>
          </div>

          <div className="card" style={{overflow:"hidden"}}>
            {ventasFiltradas.length===0
              ?<div style={{padding:40,textAlign:"center",color:"#44445a"}}><div style={{fontSize:28,marginBottom:8}}>📭</div>Sin resultados</div>
              :ventasFiltradas.map(v=>{
                const plt=platOf(v.plataforma,customPlats),days=getMinDays(v),isOpen=expanded===v.id;
                return(
                  <div key={v.id} style={{borderBottom:"1px solid #161628"}}>
                    <div className="row-item" onClick={()=>setExpanded(isOpen?null:v.id)}>
                      <div style={{display:"flex",alignItems:"center",gap:10}}>
                        <div style={{width:34,height:34,background:plt.color+"22",border:`2px solid ${plt.color}`,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:plt.color,flexShrink:0}}>{plt.icon}</div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{display:"flex",alignItems:"center",gap:7,flexWrap:"wrap"}}>
                            <span style={{fontWeight:700,fontSize:14}}>{v.cliente}</span>
                            <TagChip tagId={v.tag}/>
                            {v.usarPerfiles&&v.perfiles?.length>0&&<span style={{fontSize:10,background:"rgba(168,85,247,.15)",color:"#a855f7",padding:"2px 7px",borderRadius:20,fontWeight:700}}>👤{v.perfiles.length}</span>}
                          </div>
                          <div style={{fontSize:11,color:"#44445a"}}>{plt.name} · {v.correo||"sin correo"} · {v.telefono||"sin tel"}</div>
                          {!v.usarPerfiles&&v.monto&&<div style={{fontSize:11,color:"#ffd60a"}}>${v.monto} {v.moneda} · Vence {fmtShort(v.fechaVence)}</div>}
                        </div>
                        <div style={{display:"flex",gap:5,alignItems:"center",flexShrink:0,flexWrap:"wrap",justifyContent:"flex-end"}}>
                          <StatusBadge days={days}/>
                          <button onClick={e=>{e.stopPropagation();const t=plantillas[0];if(t)openWapp(v,t);}} style={{background:"#1a3a1a",border:"1px solid #2a5a2a",borderRadius:7,padding:"5px 8px",cursor:"pointer",color:"#30d158",fontSize:13}} title="WhatsApp">💬</button>
                          <button onClick={e=>{e.stopPropagation();setRenewId(v.id);setRenewDays(v.periodoDias||30);}} style={{background:"#1a2a1a",border:"1px solid #2a4a2a",borderRadius:7,padding:"5px 8px",cursor:"pointer",color:"#ff9f0a",fontSize:13}} title="Renovar">🔄</button>
                          <button onClick={e=>{e.stopPropagation();setShowHist(v.id);}} style={{background:"#181828",border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}} title="Historial">📋</button>
                          <button onClick={e=>{e.stopPropagation();handleEditVenta(v);}} style={{background:"#181828",border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}} title="Editar">✏️</button>
                          <button onClick={e=>{e.stopPropagation();setDelId(v.id);}} style={{background:"#2a1520",border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}} title="Eliminar">🗑️</button>
                        </div>
                      </div>
                    </div>
                    {isOpen&&(
                      <div style={{background:"#0c0c1c",padding:"10px 18px 14px",borderTop:"1px solid #1c1c2c"}}>
                        {/* Credenciales */}
                        {(v.correo||v.contrasena)&&(
                          <div style={{background:"#0c1a0c",border:"1px solid #1a3a1a",borderRadius:9,padding:"10px 14px",marginBottom:10,display:"flex",gap:20,flexWrap:"wrap"}}>
                            {v.correo&&<div><div style={{fontSize:10,color:"#44445a",fontWeight:700,marginBottom:3}}>CORREO</div><div style={{fontSize:13,color:"#a0ffa0",fontFamily:"'DM Mono',monospace"}}>{v.correo}</div></div>}
                            {v.contrasena&&<div>
                              <div style={{fontSize:10,color:"#44445a",fontWeight:700,marginBottom:3}}>CONTRASEÑA</div>
                              <div style={{display:"flex",gap:8,alignItems:"center"}}>
                                <div style={{fontSize:13,color:"#a0ffa0",fontFamily:"'DM Mono',monospace"}}>{showPass[v.id]?v.contrasena:"•".repeat(Math.min(v.contrasena?.length||6,12))}</div>
                                <button onClick={()=>setShowPass(p=>({...p,[v.id]:!p[v.id]}))} style={{background:"none",border:"none",cursor:"pointer",fontSize:14,color:"#44445a"}}>{showPass[v.id]?"🙈":"👁"}</button>
                              </div>
                            </div>}
                          </div>
                        )}
                        {/* Perfiles */}
                        {v.usarPerfiles&&v.perfiles?.length>0&&(
                          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:8}}>
                            {v.perfiles.map(p=>{
                              const pd=getDaysLeft(p.fechaVence),ps=sem(pd),t=tagOf(p.tag);
                              return(
                                <div key={p.id} style={{background:"#13132a",border:`1px solid ${ps.dot}30`,borderRadius:10,padding:"10px 12px"}}>
                                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                                    <span style={{fontWeight:700,fontSize:13}}>👤 {p.nombre||"Perfil"}</span>
                                    {t&&<TagChip tagId={p.tag} small/>}
                                  </div>
                                  <StatusBadge days={pd}/>
                                  <div style={{fontSize:11,color:"#44445a",marginTop:4}}>{fmtDate(p.fechaVence)}</div>
                                  {p.monto&&<div style={{fontSize:12,fontWeight:700,color:"#ffd60a",marginTop:2}}>${p.monto} {p.moneda}</div>}
                                </div>
                              );
                            })}
                          </div>
                        )}
                        {/* WhatsApp selección plantilla */}
                        <div style={{marginTop:10}}>
                          <div style={{fontSize:11,color:"#44445a",fontWeight:700,marginBottom:6}}>ENVIAR POR WHATSAPP</div>
                          <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
                            {plantillas.map(t=>(
                              <button key={t.id} onClick={()=>openWapp(v,t)} style={{background:"#1a3a1a",border:"1px solid #2a5a2a",borderRadius:8,padding:"6px 12px",cursor:"pointer",color:"#30d158",fontSize:12,fontWeight:700}}>
                                💬 {t.nombre}
                              </button>
                            ))}
                          </div>
                        </div>
                        {v.notas&&<div style={{marginTop:8,fontSize:12,color:"#55557a",fontStyle:"italic"}}>📝 {v.notas}</div>}
                      </div>
                    )}
                  </div>
                );
              })}
          </div>
        </div>
      )}


      {/* ════ PAGOS ════ */}
      {vista==="pagos"&&(
        <div>
          {/* Stats pagos */}
          {(()=>{
            const totalPagado=pagos.filter(p=>p.estado==="pagado").reduce((a,p)=>a+(parseFloat(p.monto)||0),0);
            const totalPendiente=pagos.filter(p=>p.estado==="pendiente").reduce((a,p)=>a+(parseFloat(p.monto)||0),0);
            const totalParcial=pagos.filter(p=>p.estado==="parcial").reduce((a,p)=>a+(parseFloat(p.monto)||0),0);
            return(
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:10,marginBottom:18}}>
                {[
                  {l:"Pagados",   v:`$${totalPagado.toFixed(0)}`,   c:"#30d158",ic:"✅"},
                  {l:"Pendientes",v:`$${totalPendiente.toFixed(0)}`, c:"#ff9f0a",ic:"⏳"},
                  {l:"Parciales", v:`$${totalParcial.toFixed(0)}`,   c:"#ffd60a",ic:"⚡"},
                  {l:"Total",     v:pagos.length,                     c:theme.accent,ic:"💳"},
                ].map(s=>(
                  <div key={s.l} className="card" style={{padding:14}}>
                    <div style={{fontSize:20,marginBottom:4}}>{s.ic}</div>
                    <div style={{fontSize:22,fontWeight:800,color:s.c}}>{s.v}</div>
                    <div style={{fontSize:11,color:P.textMuted}}>{s.l}</div>
                  </div>
                ))}
              </div>
            );
          })()}
          <div className="card" style={{overflow:"hidden"}}>
            <div style={{padding:"11px 18px",borderBottom:`1px solid ${P.border2}`,fontWeight:700,fontSize:14,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span>💳 Registro de Pagos</span>
              <button onClick={()=>{setPagoForm({ventaId:"",monto:"",moneda:"USD",estado:"pendiente",fecha:new Date().toISOString().slice(0,10),notas:""});setEditPagoId(null);setShowPago(true);}} style={{background:theme.grad,border:"none",borderRadius:8,padding:"6px 14px",cursor:"pointer",color:"#fff",fontWeight:700,fontSize:12}}>+ Pago</button>
            </div>
            {pagos.length===0
              ?<div style={{padding:36,textAlign:"center",color:P.textMuted}}><div style={{fontSize:28,marginBottom:8}}>💳</div>Sin pagos registrados</div>
              :[...pagos].sort((a,b)=>b.fecha.localeCompare(a.fecha)).map(p=>{
                const v=ventas.find(x=>x.id===p.ventaId);
                const plt=v?platOf(v.plataforma,customPlats):null;
                const estadoColor=p.estado==="pagado"?"#30d158":p.estado==="parcial"?"#ffd60a":"#ff9f0a";
                const estadoBg=p.estado==="pagado"?"rgba(48,209,88,.13)":p.estado==="parcial"?"rgba(255,214,10,.13)":"rgba(255,159,10,.13)";
                const estadoLabel=p.estado==="pagado"?"✅ Pagado":p.estado==="parcial"?"⚡ Parcial":"⏳ Pendiente";
                return(
                  <div key={p.id} style={{display:"flex",alignItems:"center",gap:12,padding:"12px 18px",borderBottom:`1px solid ${P.border2}`}}>
                    {plt&&<div style={{width:32,height:32,background:plt.color+"22",border:`1.5px solid ${plt.color}`,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:plt.color,flexShrink:0}}>{plt.icon}</div>}
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontWeight:600,fontSize:14}}>{v?.cliente||"Cliente eliminado"}</div>
                      <div style={{fontSize:11,color:P.textMuted}}>{plt?.name||""} · {fmtDate(p.fecha)}</div>
                      {p.notas&&<div style={{fontSize:11,color:P.textSub,marginTop:2}}>{p.notas}</div>}
                    </div>
                    <div style={{textAlign:"right",flexShrink:0}}>
                      <div style={{fontSize:16,fontWeight:800,color:estadoColor}}>${parseFloat(p.monto).toFixed(0)}</div>
                      <div style={{fontSize:11,color:P.textMuted}}>{p.moneda}</div>
                    </div>
                    <div style={{display:"flex",flexDirection:"column",gap:5,flexShrink:0,alignItems:"flex-end"}}>
                      <div style={{background:estadoBg,color:estadoColor,padding:"3px 9px",borderRadius:20,fontSize:11,fontWeight:700}}>{estadoLabel}</div>
                      <div style={{display:"flex",gap:4}}>
                        {p.estado!=="pagado"&&<button onClick={()=>handlePagoEstado(p.id,"pagado")} style={{background:"rgba(48,209,88,.15)",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",color:"#30d158",fontSize:11,fontWeight:700}}>✅</button>}
                        {p.estado!=="parcial"&&<button onClick={()=>handlePagoEstado(p.id,"parcial")} style={{background:"rgba(255,214,10,.15)",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",color:"#ffd60a",fontSize:11,fontWeight:700}}>⚡</button>}
                        {p.estado!=="pendiente"&&<button onClick={()=>handlePagoEstado(p.id,"pendiente")} style={{background:"rgba(255,159,10,.15)",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",color:"#ff9f0a",fontSize:11,fontWeight:700}}>⏳</button>}
                        <button onClick={()=>{setPagoForm(p);setEditPagoId(p.id);setShowPago(true);}} style={{background:P.input,border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",fontSize:12}}>✏️</button>
                        <button onClick={()=>handleDeletePago(p.id)} style={{background:"rgba(255,45,85,.15)",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",fontSize:12}}>🗑️</button>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ════ RECORDATORIOS ════ */}
      {vista==="recordatorios"&&(
        <div>
          <div style={{background:"linear-gradient(135deg,rgba(255,159,10,.1),rgba(255,214,10,.05))",border:"1px solid rgba(255,159,10,.25)",borderRadius:14,padding:"14px 18px",marginBottom:18,display:"flex",gap:12,alignItems:"center"}}>
            <span style={{fontSize:28}}>🔔</span>
            <div>
              <div style={{fontWeight:700,fontSize:14,color:"#ff9f0a"}}>Recordatorios automáticos</div>
              <div style={{fontSize:12,color:P.textMuted}}>Define cuántos días antes avisar. La app te mostrará alertas y generará el link de WhatsApp listo.</div>
            </div>
          </div>
          {/* Recordatorios activos hoy */}
          {(()=>{
            const hoy=new Date().toISOString().slice(0,10);
            const activos=recordatorios.filter(r=>{
              if(!r.activo)return false;
              const v=ventas.find(x=>x.id===r.ventaId);
              if(!v)return false;
              const days=getDaysLeft(v.fechaVence);
              return days>=0&&days<=r.diasAntes;
            });
            if(activos.length===0)return null;
            return(
              <div className="card" style={{marginBottom:16,overflow:"hidden"}}>
                <div style={{padding:"11px 18px",borderBottom:`1px solid ${P.border2}`,fontWeight:700,fontSize:13,color:"#ff9f0a"}}>🚨 Recordatorios activos hoy ({activos.length})</div>
                {activos.map(r=>{
                  const v=ventas.find(x=>x.id===r.ventaId);
                  const plt=v?platOf(v.plataforma,customPlats):null;
                  const days=v?getDaysLeft(v.fechaVence):0;
                  return(
                    <div key={r.id} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 18px",borderBottom:`1px solid ${P.border2}`,background:"rgba(255,159,10,.05)"}}>
                      {plt&&<div style={{width:30,height:30,background:plt.color+"22",border:`1.5px solid ${plt.color}`,borderRadius:7,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:plt.color,flexShrink:0}}>{plt.icon}</div>}
                      <div style={{flex:1}}>
                        <div style={{fontWeight:600,fontSize:13}}>{v?.cliente}</div>
                        <div style={{fontSize:11,color:P.textMuted}}>{plt?.name} · {days===0?"Vence hoy":`Faltan ${days}d`}</div>
                        {r.mensaje&&<div style={{fontSize:11,color:P.textSub,marginTop:2,fontStyle:"italic"}}>{r.mensaje}</div>}
                      </div>
                      <button onClick={()=>{if(v){const t=data.plantillas.find(x=>x.id==="t2")||data.plantillas[0];if(t){const msg=buildWappMsg(v,t);const phone=(v.telefono||"").replace(/\D/g,"");window.open("https://wa.me/"+phone+"?text="+encodeURIComponent(msg),"_blank");}}}} style={{background:"linear-gradient(135deg,#25d366,#128c7e)",border:"none",borderRadius:8,padding:"6px 12px",cursor:"pointer",color:"#fff",fontWeight:700,fontSize:12}}>💬 WApp</button>
                    </div>
                  );
                })}
              </div>
            );
          })()}
          <div className="card" style={{overflow:"hidden"}}>
            <div style={{padding:"11px 18px",borderBottom:`1px solid ${P.border2}`,fontWeight:700,fontSize:14,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span>🔔 Mis Recordatorios</span>
              <button onClick={()=>{setRecForm({ventaId:"",diasAntes:3,mensaje:"",activo:true});setEditRecId(null);setShowRec(true);}} style={{background:theme.grad,border:"none",borderRadius:8,padding:"6px 14px",cursor:"pointer",color:"#fff",fontWeight:700,fontSize:12}}>+ Recordatorio</button>
            </div>
            {recordatorios.length===0
              ?<div style={{padding:36,textAlign:"center",color:P.textMuted}}><div style={{fontSize:28,marginBottom:8}}>🔔</div>Sin recordatorios configurados</div>
              :recordatorios.map(r=>{
                const v=ventas.find(x=>x.id===r.ventaId);
                const plt=v?platOf(v.plataforma,customPlats):null;
                const days=v?getDaysLeft(v.fechaVence):null;
                const disparado=days!==null&&days>=0&&days<=r.diasAntes;
                return(
                  <div key={r.id} style={{display:"flex",alignItems:"center",gap:12,padding:"12px 18px",borderBottom:`1px solid ${P.border2}`,opacity:r.activo?1:.5}}>
                    <div style={{width:36,height:36,background:disparado?"rgba(255,159,10,.2)":"rgba(124,124,255,.1)",border:`1.5px solid ${disparado?"#ff9f0a":P.border}`,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>🔔</div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontWeight:600,fontSize:14}}>{v?.cliente||"Cuenta eliminada"}</div>
                      <div style={{fontSize:11,color:P.textMuted}}>{plt?.name} · Avisar {r.diasAntes}d antes · Vence {v?fmtDate(v.fechaVence):"—"}</div>
                      {r.mensaje&&<div style={{fontSize:11,color:P.textSub,marginTop:2,fontStyle:"italic"}}>"{r.mensaje}"</div>}
                    </div>
                    <div style={{display:"flex",gap:6,alignItems:"center",flexShrink:0}}>
                      {disparado&&<span style={{background:"rgba(255,159,10,.15)",color:"#ff9f0a",padding:"3px 9px",borderRadius:20,fontSize:11,fontWeight:700}} className="pulse">🚨 Activo</span>}
                      <div onClick={()=>handleToggleRec(r.id)} style={{width:36,height:20,background:r.activo?theme.accent:"#252540",borderRadius:10,position:"relative",cursor:"pointer",transition:"background .2s",flexShrink:0}}>
                        <div style={{position:"absolute",top:2,left:r.activo?18:2,width:16,height:16,background:"#fff",borderRadius:"50%",transition:"left .2s"}}/>
                      </div>
                      <button onClick={()=>{setRecForm(r);setEditRecId(r.id);setShowRec(true);}} style={{background:P.input,border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}}>✏️</button>
                      <button onClick={()=>handleDeleteRec(r.id)} style={{background:"rgba(255,45,85,.15)",border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}}>🗑️</button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ════ IA MENSAJES ════ */}
      {vista==="ia"&&(
        <div>
          <div style={{background:"linear-gradient(135deg,rgba(124,124,255,.1),rgba(168,85,247,.05))",border:"1px solid rgba(124,124,255,.25)",borderRadius:14,padding:"14px 18px",marginBottom:18,display:"flex",gap:12,alignItems:"center"}}>
            <span style={{fontSize:28}}>🤖</span>
            <div>
              <div style={{fontWeight:700,fontSize:14,color:"#a855f7"}}>IA para redactar mensajes</div>
              <div style={{fontSize:12,color:P.textMuted}}>Selecciona un cliente y el tipo de mensaje. La IA redactará algo personalizado listo para WhatsApp.</div>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:16}}>
            {/* Selector cliente */}
            <div className="card" style={{overflow:"hidden"}}>
              <div style={{padding:"11px 16px",borderBottom:`1px solid ${P.border2}`,fontWeight:700,fontSize:13}}>👤 Seleccionar cuenta</div>
              <div style={{maxHeight:380,overflowY:"auto"}}>
                {ventas.length===0?<div style={{padding:24,color:P.textMuted,textAlign:"center"}}>Sin cuentas</div>
                  :ventas.map(v=>{
                    const plt=platOf(v.plataforma,customPlats),days=getMinDays(v),s=sem(days);
                    return(
                      <div key={v.id} onClick={()=>setIaVenta(iaVenta?.id===v.id?null:v)} style={{display:"flex",alignItems:"center",gap:9,padding:"10px 14px",borderBottom:`1px solid ${P.border2}`,cursor:"pointer",background:iaVenta?.id===v.id?"rgba(168,85,247,.08)":"transparent",transition:"background .15s"}}>
                        <div style={{width:28,height:28,background:plt.color+"22",border:`1.5px solid ${plt.color}`,borderRadius:7,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:plt.color,flexShrink:0}}>{plt.icon}</div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontWeight:600,fontSize:13}}>{v.cliente}</div>
                          <div style={{fontSize:11,color:P.textMuted}}>{plt.name} · {v.telefono||"sin tel"}</div>
                        </div>
                        <div style={{width:8,height:8,borderRadius:"50%",background:s.dot,flexShrink:0}}/>
                        {iaVenta?.id===v.id&&<span style={{color:"#a855f7",fontSize:14}}>✓</span>}
                      </div>
                    );
                  })}
              </div>
            </div>
            {/* Tipo de mensaje */}
            <div className="card" style={{padding:"14px 16px"}}>
              <div style={{fontWeight:700,fontSize:13,marginBottom:12}}>✍️ Tipo de mensaje</div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {[
                  {id:"renovacion",  icon:"🔄", label:"Recordatorio de renovación", desc:"Avisa que vence pronto"},
                  {id:"bienvenida",  icon:"👋", label:"Bienvenida con accesos",      desc:"Entrega correo y contraseña"},
                  {id:"cobro",       icon:"💰", label:"Recordatorio de cobro",       desc:"Pago pendiente amable"},
                  {id:"reactivacion",icon:"🔴", label:"Reactivación de cuenta",      desc:"Invita a volver tras vencimiento"},
                ].map(t=>(
                  <div key={t.id} onClick={()=>setIaTipo(t.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:10,border:`1.5px solid ${iaTipo===t.id?"#a855f7":P.border}`,background:iaTipo===t.id?"rgba(168,85,247,.1)":P.input,cursor:"pointer",transition:"all .2s"}}>
                    <span style={{fontSize:20}}>{t.icon}</span>
                    <div style={{flex:1}}>
                      <div style={{fontSize:13,fontWeight:600,color:iaTipo===t.id?"#a855f7":P.text}}>{t.label}</div>
                      <div style={{fontSize:11,color:P.textMuted}}>{t.desc}</div>
                    </div>
                    {iaTipo===t.id&&<span style={{color:"#a855f7"}}>✓</span>}
                  </div>
                ))}
              </div>
              <button onClick={handleGenerarIA} disabled={!iaVenta||iaLoading} style={{width:"100%",marginTop:14,padding:"12px",background:iaVenta&&!iaLoading?"linear-gradient(135deg,#a855f7,#7c3aed)":"#252540",border:"none",borderRadius:10,cursor:iaVenta&&!iaLoading?"pointer":"not-allowed",color:iaVenta?"#fff":"#555",fontWeight:700,fontSize:14,transition:"all .2s"}}>
                {iaLoading?"⏳ Generando mensaje…":"🤖 Generar con IA"}
              </button>
            </div>
          </div>
          {/* Resultado */}
          {(iaMsg||iaError||iaLoading)&&(
            <div className="card" style={{padding:"16px 18px"}}>
              <div style={{fontWeight:700,fontSize:13,marginBottom:10,color:"#a855f7"}}>✨ Mensaje generado</div>
              {iaLoading&&(
                <div style={{textAlign:"center",padding:"24px 0",color:P.textMuted}}>
                  <div style={{fontSize:32,marginBottom:8}} className="pulse">🤖</div>
                  <div>Redactando mensaje personalizado…</div>
                </div>
              )}
              {iaError&&<div style={{color:"#ff2d55",fontSize:13,padding:"12px",background:"rgba(255,45,85,.1)",borderRadius:8}}>{iaError}</div>}
              {iaMsg&&!iaLoading&&(
                <>
                  <div style={{background:P.input,border:`1px solid ${P.border}`,borderRadius:12,padding:14,fontSize:13,lineHeight:1.8,color:P.text,whiteSpace:"pre-wrap",marginBottom:12,maxHeight:220,overflowY:"auto"}}>{iaMsg}</div>
                  <div style={{display:"flex",gap:10}}>
                    <button onClick={()=>{navigator.clipboard.writeText(iaMsg).then(()=>showToast("Mensaje copiado ✓"));}} style={{flex:1,padding:"10px",background:P.input,border:`1px solid ${P.border}`,borderRadius:10,cursor:"pointer",color:P.text,fontWeight:600,fontSize:13}}>📋 Copiar</button>
                    {iaVenta?.telefono&&(
                      <button onClick={()=>{const phone=iaVenta.telefono.replace(/\D/g,"");window.open("https://wa.me/"+phone+"?text="+encodeURIComponent(iaMsg),"_blank");}} style={{flex:2,padding:"10px",background:"linear-gradient(135deg,#25d366,#128c7e)",border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700,fontSize:13}}>💬 Enviar por WhatsApp</button>
                    )}
                    <button onClick={handleGenerarIA} style={{flex:1,padding:"10px",background:"linear-gradient(135deg,#a855f7,#7c3aed)",border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:600,fontSize:13}}>🔄 Regenerar</button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* ════ PLATAFORMAS ════ */}
      {vista==="plats"&&(
        <div>
          {porPlat.length===0?<div style={{textAlign:"center",color:"#44445a",padding:60}}>Sin datos aún</div>
            :<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(310px,1fr))",gap:16}}>
              {porPlat.map(([pid,items])=>{
                const plt=platOf(pid,customPlats),sorted=[...items].sort((a,b)=>getMinDays(a)-getMinDays(b));
                const tot=items.reduce((acc2,vv)=>{if(vv.usarPerfiles)return acc2+(vv.perfiles||[]).reduce((ss,pp)=>ss+(parseFloat(pp.monto)||0),0);return acc2+(parseFloat(vv.monto)||0);},0);
                return(
                  <div key={pid} className="card" style={{overflow:"hidden"}}>
                    <div style={{background:plt.color+"15",borderBottom:`2px solid ${plt.color}30`,padding:"12px 16px",display:"flex",alignItems:"center",gap:10}}>
                      <div style={{width:36,height:36,background:plt.color+"28",border:`2px solid ${plt.color}`,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:plt.color}}>{plt.icon}</div>
                      <div><div style={{fontWeight:700}}>{plt.name}</div><div style={{fontSize:11,color:"#44445a"}}>{items.length} cuenta{items.length!==1?"s":""}</div></div>
                      <div style={{marginLeft:"auto",fontWeight:700,color:"#ffd60a"}}>${tot.toFixed(0)}</div>
                    </div>
                    {sorted.map(v=>{const days=getMinDays(v),s=sem(days);return(
                      <div key={v.id} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 14px",borderBottom:"1px solid #161628"}}>
                        <div style={{width:6,height:6,borderRadius:"50%",background:s.dot,flexShrink:0}} className={days<=3&&days>=0?"pulse":""}/>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontSize:13,fontWeight:600}}>{v.cliente} {v.usarPerfiles&&v.perfiles?.length>0&&<span style={{fontSize:10,color:"#a855f7"}}>👤{v.perfiles.length}</span>}</div>
                          <div style={{fontSize:11,color:"#44445a",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{v.correo||"sin correo"}</div>
                        </div>
                        <div style={{textAlign:"right",flexShrink:0}}>
                          <div style={{fontSize:12,fontWeight:700,color:s.dot}}>{days<0?"Vencido":days===0?"Hoy":`${days}d`}</div>
                          {!v.usarPerfiles&&v.monto&&<div style={{fontSize:11,color:"#ffd60a"}}>${v.monto}</div>}
                        </div>
                      </div>
                    );})}
                  </div>
                );
              })}
            </div>
          }
        </div>
      )}

      {/* ════ GASTOS ════ */}
      {vista==="gastos"&&(
        <div>
          {/* Resumen */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:10,marginBottom:18}}>
            {[
              {l:"Total Gastos",v:`$${stats.gastos.toFixed(0)}`,c:"#ff6b6b",ic:"💸"},
              {l:"Ingresos",    v:`$${stats.ingresos.toFixed(0)}`,c:"#ffd60a",ic:"💰"},
              {l:"Neto",        v:`$${stats.neto.toFixed(0)}`,c:stats.neto>=0?"#30d158":"#ff2d55",ic:"📈"},
              {l:"Registros",   v:gastos.length,c:"#7c7cff",ic:"📋"},
            ].map(s=>(
              <div key={s.l} className="card" style={{padding:14}}>
                <div style={{fontSize:20,marginBottom:4}}>{s.ic}</div>
                <div style={{fontSize:22,fontWeight:800,color:s.c}}>{s.v}</div>
                <div style={{fontSize:11,color:"#44445a"}}>{s.l}</div>
              </div>
            ))}
          </div>

          <div className="card" style={{overflow:"hidden"}}>
            <div style={{padding:"11px 18px",borderBottom:"1px solid #161628",fontWeight:700,fontSize:14}}>💸 Registro de Gastos</div>
            {gastos.length===0
              ?<div style={{padding:36,textAlign:"center",color:"#44445a"}}><div style={{fontSize:28,marginBottom:8}}>💸</div>Sin gastos registrados</div>
              :[...gastos].sort((a,b)=>b.fecha.localeCompare(a.fecha)).map(g=>(
                <div key={g.id} style={{display:"flex",alignItems:"center",gap:12,padding:"12px 18px",borderBottom:"1px solid #161628"}}>
                  <div style={{width:36,height:36,background:"rgba(255,107,107,.15)",border:"1px solid rgba(255,107,107,.3)",borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>💸</div>
                  <div style={{flex:1}}>
                    <div style={{fontWeight:600,fontSize:14}}>{g.descripcion}</div>
                    <div style={{fontSize:11,color:"#44445a"}}>{g.categoria} · {fmtDate(g.fecha)}</div>
                    {g.notas&&<div style={{fontSize:11,color:"#55557a"}}>{g.notas}</div>}
                  </div>
                  <div style={{textAlign:"right",flexShrink:0}}>
                    <div style={{fontSize:15,fontWeight:800,color:"#ff6b6b"}}>-${parseFloat(g.monto).toFixed(0)}</div>
                    <div style={{fontSize:11,color:"#44445a"}}>{g.moneda}</div>
                  </div>
                  <div style={{display:"flex",gap:5}}>
                    <button onClick={()=>{setGastoForm(g);setEditGastoId(g.id);setShowGasto(true);}} style={{background:"#181828",border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}}>✏️</button>
                    <button onClick={()=>handleDeleteGasto(g.id)} style={{background:"#2a1520",border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}}>🗑️</button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* ════ WHATSAPP ════ */}
      {vista==="wapp"&&(
        <div>
          <div style={{background:"linear-gradient(135deg,rgba(37,211,102,.1),rgba(37,211,102,.05))",border:"1px solid rgba(37,211,102,.25)",borderRadius:14,padding:"16px 18px",marginBottom:18,display:"flex",gap:12,alignItems:"center"}}>
            <span style={{fontSize:28}}>💬</span>
            <div><div style={{fontWeight:700,fontSize:14,color:"#25d366"}}>Enviar mensajes de WhatsApp</div><div style={{fontSize:12,color:"#44445a"}}>Selecciona una cuenta y una plantilla para enviar</div></div>
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
            <div className="card" style={{overflow:"hidden"}}>
              <div style={{padding:"11px 16px",borderBottom:"1px solid #161628",fontWeight:700,fontSize:13}}>📋 Seleccionar cuenta</div>
              <div style={{maxHeight:400,overflowY:"auto"}}>
                {ventas.length===0?<div style={{padding:24,color:"#44445a",textAlign:"center"}}>Sin cuentas</div>
                  :ventas.map(v=>{
                    const plt=platOf(v.plataforma,customPlats),days=getMinDays(v),s=sem(days);
                    return(
                      <div key={v.id} onClick={()=>setWappVenta(wappVenta?.id===v.id?null:v)} style={{display:"flex",alignItems:"center",gap:9,padding:"10px 14px",borderBottom:"1px solid #161628",cursor:"pointer",background:wappVenta?.id===v.id?"rgba(37,211,102,.08)":"transparent",transition:"background .15s"}}>
                        <div style={{width:28,height:28,background:plt.color+"22",border:`1.5px solid ${plt.color}`,borderRadius:7,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:plt.color,flexShrink:0}}>{plt.icon}</div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontWeight:600,fontSize:13}}>{v.cliente}</div>
                          <div style={{fontSize:11,color:"#44445a"}}>{v.telefono||"sin teléfono"}</div>
                        </div>
                        <div style={{width:8,height:8,borderRadius:"50%",background:s.dot,flexShrink:0}}/>
                        {wappVenta?.id===v.id&&<span style={{color:"#25d366",fontSize:14}}>✓</span>}
                      </div>
                    );
                  })}
              </div>
            </div>

            <div className="card" style={{overflow:"hidden"}}>
              <div style={{padding:"11px 16px",borderBottom:"1px solid #161628",fontWeight:700,fontSize:13}}>📄 Seleccionar plantilla</div>
              <div>
                {plantillas.map(t=>(
                  <div key={t.id} onClick={()=>{setWappTpl(wappTpl?.id===t.id?null:t);if(wappVenta&&t)setWappMsg(buildWappMsg(wappVenta,t));}} style={{padding:"10px 14px",borderBottom:"1px solid #161628",cursor:"pointer",background:wappTpl?.id===t.id?"rgba(37,211,102,.08)":"transparent",transition:"background .15s"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div style={{fontWeight:600,fontSize:13}}>{t.nombre}</div>
                      {wappTpl?.id===t.id&&<span style={{color:"#25d366"}}>✓</span>}
                    </div>
                    <div style={{fontSize:11,color:"#44445a",marginTop:3,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.texto.substring(0,60)}…</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Preview */}
          {wappVenta&&wappTpl&&(
            <div className="card" style={{marginTop:14,padding:"16px 18px"}}>
              <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>👁 Vista previa del mensaje</div>
              <div style={{display:"flex",gap:10,marginBottom:12}}>
                <div style={{flex:1}}>
                  <label style={{fontSize:11,color:"#44445a",fontWeight:700,display:"block",marginBottom:4}}>TELÉFONO (con código de país)</label>
                  <input className="ifield" placeholder="+1234567890" value={wappPhone} onChange={e=>setWappPhone(e.target.value)}/>
                </div>
              </div>
              <div style={{background:"#1a2a1a",border:"1px solid #2a5a2a",borderRadius:12,padding:14,marginBottom:12,fontSize:13,lineHeight:1.7,color:"#d0ffd0",whiteSpace:"pre-wrap",maxHeight:200,overflowY:"auto"}}>
                {buildWappMsg(wappVenta,wappTpl)}
              </div>
              <div style={{display:"flex",gap:10}}>
                <button onClick={()=>{const msg=buildWappMsg(wappVenta,wappTpl);navigator.clipboard.writeText(msg).then(()=>showToast("Mensaje copiado ✓"));}} style={{flex:1,padding:"10px",background:"#181828",border:"1px solid #252540",borderRadius:10,cursor:"pointer",color:"#e2e2f0",fontWeight:600,fontSize:13}}>
                  📋 Copiar
                </button>
                <button onClick={()=>{const phone=wappPhone.replace(/\D/g,"");const msg=buildWappMsg(wappVenta,wappTpl);window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`,"_blank");}} disabled={!wappPhone.trim()} style={{flex:2,padding:"10px",background:wappPhone.trim()?"linear-gradient(135deg,#25d366,#128c7e)":"#252525",border:"none",borderRadius:10,cursor:wappPhone.trim()?"pointer":"not-allowed",color:"#fff",fontWeight:700,fontSize:13,opacity:wappPhone.trim()?1:.5}}>
                  💬 Abrir en WhatsApp
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ════ PLANTILLAS ════ */}
      {vista==="plantillas"&&(
        <div>
          <div style={{background:"#0d0d1c",border:"1px solid #1c1c30",borderRadius:12,padding:"12px 16px",marginBottom:16,fontSize:12,color:"#8888aa",lineHeight:1.7}}>
            <div style={{fontWeight:700,color:"#c0c0e0",marginBottom:4}}>Variables disponibles:</div>
            {["{{cliente}}","{{plataforma}}","{{correo}}","{{contrasena}}","{{fechaVence}}","{{monto}}","{{moneda}}","{{telefono}}"].map(varName=>(
              <span key={varName} style={{background:"#181838",color:"#9898ff",padding:"2px 8px",borderRadius:6,fontSize:11,marginRight:6,marginBottom:4,display:"inline-block"}}>{varName}</span>
            ))}
          </div>

          {/* Form nueva plantilla */}
          {(editTpl===null&&!editTpl)||editTpl!==undefined?(
            editTpl!==undefined&&(
              <div className="card" style={{padding:"16px 18px",marginBottom:14}}>
                <div style={{fontWeight:700,fontSize:14,marginBottom:12}}>{editTpl?"Editar plantilla":"Nueva plantilla"}</div>
                <div style={{display:"flex",flexDirection:"column",gap:10}}>
                  <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Nombre</label><input className="ifield" placeholder="Ej: Recordatorio de pago" value={tplForm.nombre} onChange={e=>setTplForm({...tplForm,nombre:e.target.value})}/></div>
                  <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Mensaje</label><textarea className="ifield" rows={6} placeholder="Escribe el mensaje con variables…" value={tplForm.texto} onChange={e=>setTplForm({...tplForm,texto:e.target.value})} style={{resize:"vertical"}}/></div>
                  <div style={{display:"flex",gap:10}}>
                    <button onClick={()=>setEditTpl(undefined)} style={{flex:1,padding:10,background:"#181828",border:"none",borderRadius:10,cursor:"pointer",color:"#888",fontWeight:600}}>Cancelar</button>
                    <button onClick={handleSaveTpl} style={{flex:2,padding:10,background:"linear-gradient(135deg,#5c5cff,#9b3dff)",border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>Guardar plantilla</button>
                  </div>
                </div>
              </div>
            )
          ):null}

          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:12}}>
            {plantillas.map(t=>(
              <div key={t.id} className="card" style={{padding:"14px 16px"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                  <div style={{fontWeight:700,fontSize:14}}>📄 {t.nombre}</div>
                  <div style={{display:"flex",gap:6}}>
                    <button onClick={()=>{setEditTpl(t.id);setTplForm({nombre:t.nombre,texto:t.texto});}} style={{background:"#181828",border:"none",borderRadius:7,padding:"4px 8px",cursor:"pointer",fontSize:12}}>✏️</button>
                    <button onClick={()=>handleDeleteTpl(t.id)} style={{background:"#2a1520",border:"none",borderRadius:7,padding:"4px 8px",cursor:"pointer",fontSize:12}}>🗑️</button>
                  </div>
                </div>
                <div style={{fontSize:12,color:"#8888aa",background:"#0d0d1c",borderRadius:8,padding:"10px 12px",whiteSpace:"pre-wrap",maxHeight:120,overflowY:"auto",lineHeight:1.6}}>{t.texto}</div>
              </div>
            ))}
          </div>
          {editTpl===undefined&&(
            <button onClick={()=>{setEditTpl(null);setTplForm({nombre:"",texto:""}); setTimeout(()=>setEditTpl(null),0);}} style={{marginTop:14,width:"100%",padding:12,background:"#181828",border:"2px dashed #252540",borderRadius:12,cursor:"pointer",color:"#55557a",fontWeight:700,fontSize:13}}>+ Nueva plantilla</button>
          )}
        </div>
      )}

      {/* ════ CLIENTES ════ */}
      {vista==="clientes"&&(()=>{
        // Build enriched client list from ventas
        const clientMap={};
        ventas.forEach(v=>{
          const key=v.cliente.trim().toLowerCase();
          if(!clientMap[key]){
            clientMap[key]={
              nombre:v.cliente,
              telefono:v.telefono||"",
              correo:v.correo||"",
              tag:v.tag||"regular",
              cuentas:[],
              totalIngresos:0,
              ultimaActividad:"",
            };
          }
          const ingresos=v.usarPerfiles?(v.perfiles||[]).reduce((a,p)=>a+(parseFloat(p.monto)||0),0):(parseFloat(v.monto)||0);
          clientMap[key].cuentas.push(v);
          clientMap[key].totalIngresos+=ingresos;
          if(!clientMap[key].telefono&&v.telefono) clientMap[key].telefono=v.telefono;
          if(!clientMap[key].correo&&v.correo) clientMap[key].correo=v.correo;
          const fa=v.fechaInicio||"";
          if(fa>clientMap[key].ultimaActividad) clientMap[key].ultimaActividad=fa;
        });
        const clientList=Object.values(clientMap).sort((a,b)=>b.totalIngresos-a.totalIngresos);
        const filtered=clientList.filter(cl=>{
          if(busqCli&&!cl.nombre.toLowerCase().includes(busqCli.toLowerCase())&&!cl.telefono.includes(busqCli)&&!cl.correo.toLowerCase().includes(busqCli.toLowerCase())) return false;
          if(filtroTagCli!=="todos"&&cl.tag!==filtroTagCli) return false;
          return true;
        });
        return(
          <div>
            {/* Stats */}
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))",gap:10,marginBottom:18}}>
              {[
                {l:"Total clientes",v:clientList.length,ic:"👥",c:"#7c7cff"},
                {l:"Con alertas",v:clientList.filter(cl=>cl.cuentas.some(v=>getMinDays(v)<=7)).length,ic:"🔴",c:"#ff2d55"},
                {l:"Ingresos total",v:`$${clientList.reduce((a,cl)=>a+cl.totalIngresos,0).toFixed(0)}`,ic:"💰",c:"#ffd60a"},
                {l:"Morosos",v:clientList.filter(cl=>cl.tag==="moroso").length,ic:"⚠️",c:"#ff9f0a"},
              ].map(s=>(
                <div key={s.l} className="card" style={{padding:14}}>
                  <div style={{fontSize:18,marginBottom:4}}>{s.ic}</div>
                  <div style={{fontSize:20,fontWeight:800,color:s.c}}>{s.v}</div>
                  <div style={{fontSize:11,color:"#44445a"}}>{s.l}</div>
                </div>
              ))}
            </div>

            {/* Filtros */}
            <div style={{display:"flex",gap:8,marginBottom:14,flexWrap:"wrap"}}>
              <input className="ifield" placeholder="🔍 Buscar cliente…" value={busqCli} onChange={e=>setBusqCli(e.target.value)} style={{maxWidth:220}}/>
              <select className="ifield" value={filtroTagCli} onChange={e=>setFiltroTagCli(e.target.value)} style={{maxWidth:140}}>
                <option value="todos">Todas las etiquetas</option>
                {TAGS.map(t=><option key={t.id} value={t.id}>{t.label}</option>)}
              </select>
            </div>

            <div style={{display:"grid",gridTemplateColumns:selCliente?"1fr 1fr":"1fr",gap:14}}>
              {/* Lista */}
              <div className="card" style={{overflow:"hidden"}}>
                <div style={{padding:"11px 16px",borderBottom:"1px solid #161628",fontWeight:700,fontSize:13,display:"flex",justifyContent:"space-between"}}>
                  <span>👥 {filtered.length} cliente{filtered.length!==1?"s":""}</span>
                </div>
                {filtered.length===0?<div style={{padding:36,textAlign:"center",color:"#44445a"}}>Sin clientes</div>
                  :filtered.map(cl=>{
                    const hasAlert=cl.cuentas.some(v=>getMinDays(v)<=7);
                    const t=tagOf(cl.tag);
                    const isSelected=selCliente?.nombre===cl.nombre;
                    return(
                      <div key={cl.nombre} onClick={()=>setSelCliente(isSelected?null:cl)}
                        style={{display:"flex",alignItems:"center",gap:12,padding:"12px 16px",borderBottom:"1px solid #161628",cursor:"pointer",background:isSelected?"rgba(124,124,255,.08)":"transparent",transition:"background .15s"}}>
                        <div style={{width:40,height:40,background:"linear-gradient(135deg,#1e1e38,#2a2a4a)",border:`2px solid ${isSelected?"#7c7cff":"#252540"}`,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0,fontWeight:700,color:"#9898ff"}}>
                          {cl.nombre.charAt(0).toUpperCase()}
                        </div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{display:"flex",alignItems:"center",gap:6}}>
                            <span style={{fontWeight:700,fontSize:14}}>{cl.nombre}</span>
                            {t&&<span className="tag-chip" style={{background:t.bg,color:t.color,fontSize:10}}>{t.label}</span>}
                            {hasAlert&&<span style={{fontSize:10,color:"#ff2d55"}} className="pulse">🔴</span>}
                          </div>
                          <div style={{fontSize:11,color:"#44445a"}}>{cl.cuentas.length} cuenta{cl.cuentas.length!==1?"s":""} · {cl.telefono||"sin tel"}</div>
                        </div>
                        <div style={{textAlign:"right",flexShrink:0}}>
                          <div style={{fontSize:13,fontWeight:800,color:"#ffd60a"}}>${cl.totalIngresos.toFixed(0)}</div>
                          <div style={{fontSize:10,color:"#44445a"}}>{cl.correo?"✉️":""}</div>
                        </div>
                      </div>
                    );
                  })}
              </div>

              {/* Detalle cliente */}
              {selCliente&&(
                <div>
                  <div className="card" style={{padding:"16px 18px",marginBottom:12}}>
                    <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:14}}>
                      <div style={{width:52,height:52,background:"linear-gradient(135deg,#1e1e38,#2a2a4a)",border:"2px solid #7c7cff",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,fontWeight:800,color:"#9898ff",flexShrink:0}}>
                        {selCliente.nombre.charAt(0).toUpperCase()}
                      </div>
                      <div style={{flex:1}}>
                        <div style={{fontWeight:800,fontSize:16}}>{selCliente.nombre}</div>
                        {tagOf(selCliente.tag)&&<span className="tag-chip" style={{background:tagOf(selCliente.tag).bg,color:tagOf(selCliente.tag).color}}>{tagOf(selCliente.tag).label}</span>}
                      </div>
                      <button onClick={()=>{const t=plantillas[0];const v=selCliente.cuentas[0];if(t&&v){openWapp(v,t);setVista("wapp");}}} style={{background:"#1a3a1a",border:"1px solid #2a5a2a",borderRadius:8,padding:"7px 12px",cursor:"pointer",color:"#25d366",fontSize:13,fontWeight:700}}>💬 WhatsApp</button>
                    </div>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                      {[
                        {ic:"📱",l:"Teléfono",v:selCliente.telefono||"No registrado"},
                        {ic:"✉️",l:"Correo",v:selCliente.correo||"No registrado"},
                        {ic:"📦",l:"Cuentas activas",v:selCliente.cuentas.filter(v=>getMinDays(v)>0).length},
                        {ic:"💰",l:"Total pagado",v:`$${selCliente.totalIngresos.toFixed(0)}`},
                      ].map(item=>(
                        <div key={item.l} style={{background:"#0d0d1c",border:"1px solid #1c1c30",borderRadius:9,padding:"10px 12px"}}>
                          <div style={{fontSize:11,color:"#44445a",fontWeight:700,marginBottom:3}}>{item.ic} {item.l.toUpperCase()}</div>
                          <div style={{fontSize:13,fontWeight:600,color:"#c0c0e0",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{item.v}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Cuentas del cliente */}
                  <div className="card" style={{overflow:"hidden"}}>
                    <div style={{padding:"11px 16px",borderBottom:"1px solid #161628",fontWeight:700,fontSize:13}}>📋 Historial de cuentas</div>
                    {selCliente.cuentas.sort((a,b)=>getMinDays(a)-getMinDays(b)).map(v=>{
                      const plt=platOf(v.plataforma,customPlats),days=getMinDays(v),s=sem(days);
                      const ingresos=v.usarPerfiles?(v.perfiles||[]).reduce((a,p)=>a+(parseFloat(p.monto)||0),0):(parseFloat(v.monto)||0);
                      return(
                        <div key={v.id} style={{padding:"11px 16px",borderBottom:"1px solid #161628"}}>
                          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:v.historia?.length?6:0}}>
                            <div style={{width:30,height:30,background:plt.color+"22",border:`1.5px solid ${plt.color}`,borderRadius:7,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:plt.color,flexShrink:0}}>{plt.icon}</div>
                            <div style={{flex:1}}>
                              <div style={{fontWeight:600,fontSize:13}}>{plt.name}</div>
                              <div style={{fontSize:11,color:"#44445a"}}>{v.correo||"sin correo"} {!v.usarPerfiles&&v.fechaVence?"· "+fmtShort(v.fechaVence):""}</div>
                            </div>
                            <div style={{display:"flex",gap:6,alignItems:"center",flexShrink:0}}>
                              <StatusBadge days={days}/>
                              {ingresos>0&&<span style={{fontSize:12,fontWeight:700,color:"#ffd60a"}}>${ingresos.toFixed(0)}</span>}
                            </div>
                          </div>
                          {/* Mini historial renovaciones */}
                          {v.historia?.length>0&&(
                            <div style={{marginLeft:40,marginTop:4}}>
                              <div style={{fontSize:10,color:"#44445a",fontWeight:700,marginBottom:3}}>RENOVACIONES ({v.historia.length})</div>
                              {[...v.historia].reverse().slice(0,3).map(h=>(
                                <div key={h.id} style={{fontSize:11,color:"#666",display:"flex",gap:10,marginBottom:2}}>
                                  <span>🔄 {fmtShort(h.fecha)}</span>
                                  <span style={{color:"#30d158"}}>→ {fmtShort(h.fechaNueva)}</span>
                                  {h.monto&&<span style={{color:"#ffd60a"}}>${h.monto}</span>}
                                </div>
                              ))}
                              {v.historia.length>3&&<div style={{fontSize:10,color:"#44445a"}}>+{v.historia.length-3} más…</div>}
                            </div>
                          )}
                          {/* Perfiles si los tiene */}
                          {v.usarPerfiles&&v.perfiles?.length>0&&(
                            <div style={{marginLeft:40,marginTop:6,display:"flex",gap:6,flexWrap:"wrap"}}>
                              {v.perfiles.map(p=>{
                                const pd=getDaysLeft(p.fechaVence),ps=sem(pd);
                                return(
                                  <div key={p.id} style={{background:"#13132a",border:`1px solid ${ps.dot}30`,borderRadius:8,padding:"4px 10px",fontSize:11}}>
                                    <span style={{color:"#9898ff"}}>👤 {p.nombre}</span>
                                    <span style={{color:ps.dot,marginLeft:6}}>{pd<0?"Vencido":pd===0?"Hoy":`${pd}d`}</span>
                                    {p.monto&&<span style={{color:"#ffd60a",marginLeft:6}}>${p.monto}</span>}
                                  </div>
                                );
                              })}
                            </div>
                          )}
                          {/* Botones acción rápida */}
                          <div style={{marginLeft:40,marginTop:8,display:"flex",gap:6}}>
                            <button onClick={()=>{const t=plantillas.find(x=>x.id==="t2")||plantillas[0];if(t)openWapp(v,t);setVista("wapp");}} style={{background:"#1a3a1a",border:"none",borderRadius:7,padding:"4px 10px",cursor:"pointer",color:"#25d366",fontSize:11,fontWeight:700}}>💬 WApp</button>
                            <button onClick={()=>{setRenewId(v.id);setRenewDays(v.periodoDias||30);}} style={{background:"#1a2a1a",border:"none",borderRadius:7,padding:"4px 10px",cursor:"pointer",color:"#ff9f0a",fontSize:11,fontWeight:700}}>🔄 Renovar</button>
                            <button onClick={()=>{handleEditVenta(v);}} style={{background:"#181828",border:"none",borderRadius:7,padding:"4px 10px",cursor:"pointer",color:"#9898ff",fontSize:11,fontWeight:700}}>✏️ Editar</button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* ════ CONFIG ════ */}
      {vista==="config"&&(
        <div style={{maxWidth:500}}>
          <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:14,padding:"18px 20px"}}>
            <div style={{fontWeight:800,fontSize:16,marginBottom:16}}>⚙️ Configuración</div>
            <div style={{display:"flex",flexDirection:"column",gap:14}}>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Nombre del negocio</label><input className="ifield" value={config.negocio} onChange={e=>mutate({config:{...config,negocio:e.target.value}})}/></div>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Moneda por defecto</label><select className="ifield" value={config.monedaDefault} onChange={e=>mutate({config:{...config,monedaDefault:e.target.value}})}>{CURRENCIES.map(c=><option key={c}>{c}</option>)}</select></div>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Alertar cuando falten (días)</label>
                <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
                  {[3,5,7,15].map(d=>(
                    <button key={d} onClick={()=>mutate({config:{...config,alertaDias:d}})} style={{padding:"9px 4px",borderRadius:9,border:`2px solid ${config.alertaDias===d?"#7c7cff":"#252540"}`,background:config.alertaDias===d?"rgba(124,124,255,.15)":"#181828",color:config.alertaDias===d?"#9898ff":"#666",fontWeight:700,fontSize:13,cursor:"pointer"}}>{d}d</button>
                  ))}
                </div>
              </div>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Tu número de WhatsApp (para pruebas)</label><input className="ifield" placeholder="+1234567890" value={config.telefono} onChange={e=>mutate({config:{...config,telefono:e.target.value}})}/></div>

              {/* Dark/Light mode */}
              <div>
                <label style={{fontSize:12,color:P.textMuted,marginBottom:8,display:"block",fontWeight:700}}>🌙 MODO DE PANTALLA</label>
                <div style={{display:"flex",gap:10}}>
                  {[{id:true,ic:"🌙",l:"Oscuro"},{id:false,ic:"☀️",l:"Claro"}].map(m=>(
                    <button key={String(m.id)} onClick={()=>mutate({config:{...config,darkMode:m.id}})}
                      style={{flex:1,padding:"10px 8px",borderRadius:10,border:`2px solid ${darkMode===m.id?theme.accent:P.border}`,background:darkMode===m.id?theme.accent+"22":P.input,color:darkMode===m.id?theme.accent:P.textMuted,fontWeight:700,fontSize:13,cursor:"pointer",transition:"all .2s"}}>
                      {m.ic} {m.l}
                    </button>
                  ))}
                </div>
              </div>

              {/* Theme color */}
              <div>
                <label style={{fontSize:12,color:P.textMuted,marginBottom:8,display:"block",fontWeight:700}}>🎨 COLOR DEL TEMA</label>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                  {THEMES.map(t=>(
                    <button key={t.id} onClick={()=>mutate({config:{...config,themeId:t.id}})}
                      style={{padding:"10px 8px",borderRadius:10,border:`2px solid ${themeId===t.id?t.accent:P.border}`,background:themeId===t.id?t.accent+"22":P.input,cursor:"pointer",transition:"all .2s",display:"flex",alignItems:"center",gap:8}}>
                      <div style={{width:18,height:18,borderRadius:"50%",background:t.grad,flexShrink:0}}/>
                      <span style={{fontWeight:700,fontSize:12,color:themeId===t.id?t.accent:P.textMuted}}>{t.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div style={{marginTop:20,padding:"12px 14px",background:"rgba(48,209,88,.07)",border:"1px solid rgba(48,209,88,.2)",borderRadius:10,fontSize:12,color:"#44445a"}}>
              ✅ Los cambios se guardan automáticamente en la nube de Claude.
            </div>
          </div>

          {/* Plataformas personalizadas */}
          <div className="card" style={{padding:"18px 20px",marginTop:16}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
              <div style={{fontWeight:800,fontSize:15}}>🎬 Plataformas personalizadas</div>
              <button onClick={()=>{setPlatForm({name:"",icon:"",color:"#7c7cff",hasProfiles:true});setEditPlatId(null);setShowPlat(true);}} style={{background:theme.grad,border:"none",borderRadius:8,padding:"6px 14px",cursor:"pointer",color:"#fff",fontWeight:700,fontSize:12}}>+ Agregar</button>
            </div>
            {customPlats.length===0
              ?<div style={{color:P.textMuted,fontSize:13,padding:"10px 0",textAlign:"center"}}>No hay plataformas personalizadas.<br/>Agrega Canela TV, Blim, ViX, etc.</div>
              :customPlats.map(p=>(
                <div key={p.id} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",background:P.input,borderRadius:10,marginBottom:8}}>
                  <div style={{width:36,height:36,background:p.color+"22",border:`2px solid ${p.color}`,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:p.color,flexShrink:0}}>{p.icon}</div>
                  <div style={{flex:1}}><div style={{fontWeight:600}}>{p.name}</div><div style={{fontSize:11,color:P.textMuted}}>{p.hasProfiles?"Con perfiles":"Sin perfiles"}</div></div>
                  <button onClick={()=>{setPlatForm(p);setEditPlatId(p.id);setShowPlat(true);}} style={{background:P.card,border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}}>✏️</button>
                  <button onClick={()=>handleDeletePlat(p.id)} style={{background:"rgba(255,45,85,.15)",border:"none",borderRadius:7,padding:"5px 8px",cursor:"pointer",fontSize:13}}>🗑️</button>
                </div>
              ))
            }
            <div style={{marginTop:10,padding:"10px 12px",background:"rgba(124,124,255,.07)",border:"1px solid rgba(124,124,255,.2)",borderRadius:8,fontSize:11,color:P.textMuted}}>
              💡 Las plataformas agregadas aparecen en el selector al registrar ventas.
            </div>
          </div>
        </div>
      )}

      </div>
    </div>{/* end main */}

    {/* ══ MODALES ══ */}

    {/* Alertas */}
    {showAlerts&&(
      <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowAlerts(false)}>
        <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,width:"min(500px,96vw)",maxHeight:"85vh",overflow:"hidden",display:"flex",flexDirection:"column"}}>
          <div style={{padding:"16px 20px",borderBottom:"1px solid #1c1c30",display:"flex",justifyContent:"space-between"}}>
            <div><h3 style={{fontSize:16,fontWeight:800}}>🔔 Alertas</h3><div style={{fontSize:12,color:"#44445a"}}>{totalAlertas} requieren atención</div></div>
            <button onClick={()=>setShowAlerts(false)} style={{background:"none",border:"none",color:"#44445a",fontSize:20,cursor:"pointer"}}>✕</button>
          </div>
          <div style={{overflowY:"auto",flex:1}}>
            {alerts.map(v=>{
              const plt=platOf(v.plataforma,customPlats),days=getMinDays(v);
              return(
                <div key={v.id} style={{display:"flex",alignItems:"center",gap:12,padding:"13px 18px",borderBottom:"1px solid #161628"}}>
                  <div style={{width:36,height:36,background:plt.color+"22",border:`2px solid ${plt.color}`,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:plt.color,flexShrink:0}}>{plt.icon}</div>
                  <div style={{flex:1}}><div style={{fontWeight:700}}>{v.cliente} <TagChip tagId={v.tag} small/></div><div style={{fontSize:11,color:"#44445a"}}>{plt.name} · {v.telefono||"sin tel"}</div></div>
                  <div style={{display:"flex",gap:6,flexShrink:0}}>
                    <StatusBadge days={days}/>
                    <button onClick={()=>{const t=plantillas.find(x=>x.id==="t2")||plantillas[0];if(t){openWapp(v,t);setShowAlerts(false);setVista("wapp");}}} style={{background:"#1a3a1a",border:"none",borderRadius:8,padding:"5px 9px",cursor:"pointer",color:"#25d366",fontSize:13}}>💬</button>
                    <button onClick={()=>{setRenewId(v.id);setRenewDays(v.periodoDias||30);setShowAlerts(false);}} style={{background:"linear-gradient(135deg,#ff9f0a,#ff6b00)",border:"none",borderRadius:8,padding:"5px 9px",cursor:"pointer",color:"#fff",fontSize:12,fontWeight:700}}>🔄</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    )}

    {/* Renovación */}
    {renewId&&(()=>{
      const v=ventas.find(x=>x.id===renewId);if(!v)return null;
      const plt=platOf(v.plataforma,customPlats),days=getDaysLeft(v.fechaVence);
      const base=days<0?new Date().toISOString().slice(0,10):v.fechaVence;
      const preview=addDays(base,renewDays);
      return(
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setRenewId(null)}>
          <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,padding:24,width:"min(380px,96vw)"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:16}}>
              <h3 style={{fontSize:16,fontWeight:800}}>🔄 Renovación Rápida</h3>
              <button onClick={()=>setRenewId(null)} style={{background:"none",border:"none",color:"#44445a",fontSize:20,cursor:"pointer"}}>✕</button>
            </div>
            <div style={{background:plt.color+"12",border:`1px solid ${plt.color}30`,borderRadius:10,padding:"10px 14px",marginBottom:14,display:"flex",gap:10,alignItems:"center"}}>
              <div style={{width:34,height:34,background:plt.color+"22",border:`2px solid ${plt.color}`,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:plt.color,flexShrink:0}}>{plt.icon}</div>
              <div><div style={{fontWeight:700}}>{v.cliente}</div><div style={{fontSize:12,color:"#44445a"}}>{plt.name}</div></div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:7,marginBottom:10}}>
              {[7,15,30,60].map(d=>(
                <button key={d} onClick={()=>setRenewDays(d)} style={{padding:"9px 4px",borderRadius:9,border:`2px solid ${renewDays===d?plt.color:"#252540"}`,background:renewDays===d?plt.color+"22":"#181828",color:renewDays===d?plt.color:"#888",fontWeight:700,fontSize:13,cursor:"pointer"}}>{d}d</button>
              ))}
            </div>
            <input type="number" className="ifield" placeholder="Días personalizados" value={renewDays} onChange={e=>setRenewDays(parseInt(e.target.value)||30)} style={{textAlign:"center",marginBottom:12}}/>
            <div style={{background:"#0d0d1c",border:"1px solid #1c1c30",borderRadius:10,padding:"11px 14px",marginBottom:14}}>
              <div style={{fontSize:11,color:"#44445a",fontWeight:700,marginBottom:2}}>NUEVA FECHA</div>
              <div style={{fontSize:18,fontWeight:800,color:"#30d158"}}>{fmtDate(preview)}</div>
              <div style={{fontSize:11,color:"#44445a"}}>{days<0?"Desde hoy":"Desde vencimiento"} + {renewDays}d</div>
            </div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setRenewId(null)} style={{flex:1,padding:11,background:"#181828",border:"none",borderRadius:10,cursor:"pointer",color:"#888",fontWeight:600}}>Cancelar</button>
              <button onClick={()=>handleRenew(renewId,renewDays)} style={{flex:2,padding:11,background:"linear-gradient(135deg,#30d158,#1a8a3a)",border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>✅ Confirmar</button>
            </div>
          </div>
        </div>
      );
    })()}

    {/* Historial */}
    {showHist&&(()=>{
      const v=ventas.find(x=>x.id===showHist);if(!v)return null;
      const hist=v.historia||[];
      return(
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowHist(null)}>
          <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,width:"min(440px,96vw)",maxHeight:"80vh",overflow:"hidden",display:"flex",flexDirection:"column"}}>
            <div style={{padding:"14px 18px",borderBottom:"1px solid #1c1c30",display:"flex",justifyContent:"space-between"}}>
              <div><h3 style={{fontSize:15,fontWeight:800}}>📋 Historial</h3><div style={{fontSize:12,color:"#44445a"}}>{v.cliente}</div></div>
              <button onClick={()=>setShowHist(null)} style={{background:"none",border:"none",color:"#44445a",fontSize:20,cursor:"pointer"}}>✕</button>
            </div>
            <div style={{overflowY:"auto",flex:1}}>
              {hist.length===0?<div style={{padding:32,textAlign:"center",color:"#44445a"}}>Sin renovaciones aún</div>
                :[...hist].reverse().map((h,i)=>(
                  <div key={h.id} style={{display:"flex",gap:12,padding:"13px 18px",borderBottom:"1px solid #161628"}}>
                    <div style={{width:30,height:30,background:"rgba(48,209,88,.15)",border:"1px solid rgba(48,209,88,.3)",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0}}>🔄</div>
                    <div>
                      <div style={{fontWeight:700,fontSize:13,color:"#30d158"}}>Renovación #{hist.length-i}</div>
                      <div style={{fontSize:12,color:"#44445a"}}>Realizada: {fmtDate(h.fecha)}</div>
                      <div style={{display:"flex",gap:12,marginTop:5,flexWrap:"wrap"}}>
                        <div style={{fontSize:12}}><span style={{color:"#666"}}>Anterior: </span><span style={{color:"#ff6b6b"}}>{fmtDate(h.fechaAnterior)}</span></div>
                        <div style={{fontSize:12}}><span style={{color:"#666"}}>Nueva: </span><span style={{color:"#30d158"}}>{fmtDate(h.fechaNueva)}</span></div>
                        <div style={{fontSize:12}}><span style={{color:"#666"}}>Período: </span><span style={{color:"#ffd60a"}}>{h.dias}d</span></div>
                        {h.monto&&<div style={{fontSize:12}}><span style={{color:"#666"}}>$</span><span style={{color:"#ffd60a"}}>{h.monto} {h.moneda}</span></div>}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      );
    })()}

    {/* Form Venta */}
    {showForm&&(
      <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowForm(false)}>
        <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,padding:22,width:"min(540px,96vw)",maxHeight:"94vh",overflowY:"auto"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:16}}>
            <h3 style={{fontSize:16,fontWeight:800}}>{editId?"Editar Cuenta":"Nueva Cuenta"}</h3>
            <button onClick={()=>setShowForm(false)} style={{background:"none",border:"none",color:"#44445a",fontSize:20,cursor:"pointer"}}>✕</button>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <div style={{display:"grid",gridTemplateColumns:"1fr 130px",gap:10}}>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Cliente *</label><input className="ifield" placeholder="Nombre" value={form.cliente} onChange={e=>setForm({...form,cliente:e.target.value})}/></div>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Etiqueta</label><select className="ifield" value={form.tag} onChange={e=>setForm({...form,tag:e.target.value})}>{TAGS.map(t=><option key={t.id} value={t.id}>{t.label}</option>)}</select></div>
            </div>
            <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Plataforma *</label><select className="ifield" value={form.plataforma} onChange={e=>setForm({...form,plataforma:e.target.value,usarPerfiles:false,perfiles:[]})}>{allPlatforms.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
            <div style={{background:"#0d0d1c",border:"1px solid #1c1c30",borderRadius:10,padding:"12px 14px"}}>
              <div style={{fontSize:12,color:"#7c7caa",fontWeight:700,marginBottom:10}}>🔑 Credenciales</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                <div><label style={{fontSize:11,color:"#44445a",marginBottom:4,display:"block",fontWeight:600}}>Correo</label><input className="ifield" type="email" placeholder="correo@…" value={form.correo} onChange={e=>setForm({...form,correo:e.target.value})}/></div>
                <div><label style={{fontSize:11,color:"#44445a",marginBottom:4,display:"block",fontWeight:600}}>Contraseña</label>
                  <div style={{position:"relative"}}>
                    <input className="ifield" type={showPass.__form?"text":"password"} placeholder="••••••" value={form.contrasena} onChange={e=>setForm({...form,contrasena:e.target.value})} style={{paddingRight:38}}/>
                    <button type="button" onClick={()=>setShowPass(p=>({...p,__form:!p.__form}))} style={{position:"absolute",right:10,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",fontSize:14,color:"#44445a"}}>{showPass.__form?"🙈":"👁"}</button>
                  </div>
                </div>
              </div>
              <div style={{marginTop:10}}><label style={{fontSize:11,color:"#44445a",marginBottom:4,display:"block",fontWeight:600}}>📱 Teléfono WhatsApp</label><input className="ifield" placeholder="+1234567890" value={form.telefono} onChange={e=>setForm({...form,telefono:e.target.value})}/></div>
            </div>
            {platOf(form.plataforma,customPlats).hasProfiles&&(
              <div style={{display:"flex",alignItems:"center",gap:10,background:"#0d0d1c",border:"1px solid #1c1c30",borderRadius:10,padding:"11px 14px",cursor:"pointer"}} onClick={()=>setForm(f=>({...f,usarPerfiles:!f.usarPerfiles,perfiles:[]}))}>
                <div style={{width:36,height:20,background:form.usarPerfiles?"#5c5cff":"#252540",borderRadius:10,position:"relative",transition:"background .2s",flexShrink:0}}>
                  <div style={{position:"absolute",top:2,left:form.usarPerfiles?18:2,width:16,height:16,background:"#fff",borderRadius:"50%",transition:"left .2s"}}/>
                </div>
                <div><div style={{fontSize:13,fontWeight:700}}>Gestionar por perfiles</div><div style={{fontSize:11,color:"#44445a"}}>Cada perfil con su fecha y precio</div></div>
              </div>
            )}
            {!form.usarPerfiles&&(
              <>
                <div style={{display:"grid",gridTemplateColumns:"1fr 90px",gap:10}}>
                  <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Monto</label><input className="ifield" type="number" placeholder="0.00" value={form.monto} onChange={e=>setForm({...form,monto:e.target.value})}/></div>
                  <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Moneda</label><select className="ifield" value={form.moneda} onChange={e=>setForm({...form,moneda:e.target.value})}>{CURRENCIES.map(c=><option key={c}>{c}</option>)}</select></div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                  <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Fecha inicio</label><input className="ifield" type="date" value={form.fechaInicio} onChange={e=>setForm({...form,fechaInicio:e.target.value})}/></div>
                  <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Fecha vencimiento *</label><input className="ifield" type="date" value={form.fechaVence} onChange={e=>setForm({...form,fechaVence:e.target.value})}/></div>
                </div>
              </>
            )}
            {form.usarPerfiles&&(
              <div style={{background:"#0d0d1c",border:"1px solid #252540",borderRadius:10,padding:"12px 14px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
                  <div style={{fontSize:12,color:"#7c7caa",fontWeight:700}}>👤 Perfiles</div>
                  <button onClick={()=>setForm(f=>({...f,perfiles:[...f.perfiles,emptyProfile()]}))} style={{background:"linear-gradient(135deg,#5c5cff,#9b3dff)",border:"none",borderRadius:7,padding:"4px 12px",cursor:"pointer",color:"#fff",fontSize:12,fontWeight:700}}>+ Añadir</button>
                </div>
                {form.perfiles.length===0&&<div style={{color:"#44445a",fontSize:13,textAlign:"center",padding:"10px 0"}}>Toca "+ Añadir" para crear perfiles</div>}
                {form.perfiles.map((p,i)=>(
                  <div key={p.id} style={{background:"#13132a",border:"1px solid #252540",borderRadius:9,padding:"10px 12px",marginBottom:8}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:7}}>
                      <span style={{fontSize:12,fontWeight:700,color:"#9898ff"}}>Perfil {i+1}</span>
                      <button onClick={()=>setForm(f=>({...f,perfiles:f.perfiles.filter(x=>x.id!==p.id)}))} style={{background:"#2a1520",border:"none",borderRadius:6,padding:"2px 8px",cursor:"pointer",color:"#ff2d55",fontSize:11,fontWeight:700}}>✕</button>
                    </div>
                    <div style={{display:"flex",flexDirection:"column",gap:7}}>
                      <input className="ifield" placeholder="Nombre del perfil" value={p.nombre} onChange={e=>setForm(f=>({...f,perfiles:f.perfiles.map(x=>x.id===p.id?{...x,nombre:e.target.value}:x)}))} style={{fontSize:13,padding:"7px 12px"}}/>
                      <div style={{display:"grid",gridTemplateColumns:"1fr 70px 1fr",gap:7}}>
                        <input className="ifield" type="number" placeholder="Monto" value={p.monto} onChange={e=>setForm(f=>({...f,perfiles:f.perfiles.map(x=>x.id===p.id?{...x,monto:e.target.value}:x)}))} style={{fontSize:12,padding:"7px 10px"}}/>
                        <select className="ifield" value={p.moneda||"USD"} onChange={e=>setForm(f=>({...f,perfiles:f.perfiles.map(x=>x.id===p.id?{...x,moneda:e.target.value}:x)}))} style={{fontSize:11,padding:"7px 6px"}}>{CURRENCIES.map(c=><option key={c}>{c}</option>)}</select>
                        <input className="ifield" type="date" value={p.fechaVence} onChange={e=>setForm(f=>({...f,perfiles:f.perfiles.map(x=>x.id===p.id?{...x,fechaVence:e.target.value}:x)}))} style={{fontSize:11,padding:"7px 8px"}}/>
                      </div>
                      <select className="ifield" value={p.tag||"regular"} onChange={e=>setForm(f=>({...f,perfiles:f.perfiles.map(x=>x.id===p.id?{...x,tag:e.target.value}:x)}))} style={{fontSize:12,padding:"7px 12px"}}>{TAGS.map(t=><option key={t.id} value={t.id}>{t.label}</option>)}</select>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div><label style={{fontSize:12,color:"#44445a",marginBottom:6,display:"block",fontWeight:700}}>Período de renovación</label>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:7}}>
                {[7,15,30,60].map(d=>(
                  <button key={d} type="button" onClick={()=>setForm({...form,periodoDias:d})} style={{padding:"8px 4px",borderRadius:9,border:`2px solid ${form.periodoDias===d?"#7c7cff":"#252540"}`,background:form.periodoDias===d?"rgba(124,124,255,.15)":"#181828",color:form.periodoDias===d?"#9898ff":"#666",fontWeight:700,fontSize:13,cursor:"pointer"}}>{d}d</button>
                ))}
              </div>
            </div>
            <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Notas</label><textarea className="ifield" placeholder="Observaciones…" value={form.notas} onChange={e=>setForm({...form,notas:e.target.value})} rows={2} style={{resize:"vertical"}}/></div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setShowForm(false)} style={{flex:1,padding:12,background:"#181828",border:"none",borderRadius:10,cursor:"pointer",color:"#888",fontWeight:600}}>Cancelar</button>
              <button onClick={handleSaveVenta} style={{flex:2,padding:12,background:theme.grad,border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>{editId?"Guardar cambios":"Registrar cuenta"}</button>
            </div>
          </div>
        </div>
      </div>
    )}

    {/* Form Gasto */}
    {showGasto&&(
      <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowGasto(false)}>
        <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,padding:22,width:"min(420px,96vw)"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:16}}>
            <h3 style={{fontSize:16,fontWeight:800}}>{editGastoId?"Editar Gasto":"Nuevo Gasto"}</h3>
            <button onClick={()=>setShowGasto(false)} style={{background:"none",border:"none",color:"#44445a",fontSize:20,cursor:"pointer"}}>✕</button>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Descripción *</label><input className="ifield" placeholder="Ej: Cuenta Netflix propia" value={gastoForm.descripcion} onChange={e=>setGastoForm({...gastoForm,descripcion:e.target.value})}/></div>
            <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Categoría</label><select className="ifield" value={gastoForm.categoria} onChange={e=>setGastoForm({...gastoForm,categoria:e.target.value})}>{EXPENSE_CATS.map(c=><option key={c}>{c}</option>)}</select></div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 90px",gap:10}}>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Monto *</label><input className="ifield" type="number" placeholder="0.00" value={gastoForm.monto} onChange={e=>setGastoForm({...gastoForm,monto:e.target.value})}/></div>
              <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Moneda</label><select className="ifield" value={gastoForm.moneda} onChange={e=>setGastoForm({...gastoForm,moneda:e.target.value})}>{CURRENCIES.map(c=><option key={c}>{c}</option>)}</select></div>
            </div>
            <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Fecha</label><input className="ifield" type="date" value={gastoForm.fecha} onChange={e=>setGastoForm({...gastoForm,fecha:e.target.value})}/></div>
            <div><label style={{fontSize:12,color:"#44445a",marginBottom:4,display:"block",fontWeight:700}}>Notas</label><textarea className="ifield" placeholder="Opcional…" value={gastoForm.notas} onChange={e=>setGastoForm({...gastoForm,notas:e.target.value})} rows={2} style={{resize:"vertical"}}/></div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setShowGasto(false)} style={{flex:1,padding:11,background:"#181828",border:"none",borderRadius:10,cursor:"pointer",color:"#888",fontWeight:600}}>Cancelar</button>
              <button onClick={handleSaveGasto} style={{flex:2,padding:11,background:"linear-gradient(135deg,#ff2d55,#ff6b6b)",border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>Guardar gasto</button>
            </div>
          </div>
        </div>
      </div>
    )}

    {/* ══ MODAL PLATAFORMA PERSONALIZADA ══ */}
    {showPlat&&(
      <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowPlat(false)}>
        <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,padding:24,width:"min(400px,96vw)"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:18}}>
            <h3 style={{fontSize:16,fontWeight:800}}>{editPlatId?"Editar Plataforma":"Nueva Plataforma"}</h3>
            <button onClick={()=>setShowPlat(false)} style={{background:"none",border:"none",color:P.textMuted,fontSize:20,cursor:"pointer"}}>✕</button>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Nombre de la plataforma *</label>
              <input className="ifield" placeholder="Ej: Canela TV, Blim, ViX..." value={platForm.name} onChange={e=>setPlatForm({...platForm,name:e.target.value})}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Ícono (2-3 letras)</label>
                <input className="ifield" placeholder="Ej: CT, BL, VX" maxLength={3} value={platForm.icon} onChange={e=>setPlatForm({...platForm,icon:e.target.value.toUpperCase()})}/>
              </div>
              <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Color</label>
                <div style={{display:"flex",gap:8,alignItems:"center"}}>
                  <input type="color" value={platForm.color} onChange={e=>setPlatForm({...platForm,color:e.target.value})} style={{width:42,height:42,border:"none",borderRadius:8,cursor:"pointer",background:"none"}}/>
                  <input className="ifield" value={platForm.color} onChange={e=>setPlatForm({...platForm,color:e.target.value})} style={{fontSize:12}}/>
                </div>
              </div>
            </div>
            {/* Preview */}
            <div style={{display:"flex",alignItems:"center",gap:12,padding:"12px 14px",background:P.input,borderRadius:10}}>
              <div style={{fontSize:11,color:P.textMuted,fontWeight:700}}>VISTA PREVIA:</div>
              <div style={{width:40,height:40,background:platForm.color+"22",border:`2px solid ${platForm.color}`,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:platForm.color}}>
                {platForm.icon||platForm.name.slice(0,2).toUpperCase()||"?"}
              </div>
              <div style={{fontWeight:600}}>{platForm.name||"Mi Plataforma"}</div>
            </div>
            {/* Colores rápidos */}
            <div>
              <label style={{fontSize:12,color:P.textMuted,marginBottom:6,display:"block",fontWeight:700}}>Colores rápidos</label>
              <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                {["#E50914","#113CCF","#1DB954","#FF0000","#F97316","#A855F7","#06B6D4","#EF4444","#10B981","#F59E0B","#EC4899","#6366F1"].map(color=>(
                  <div key={color} onClick={()=>setPlatForm({...platForm,color})} style={{width:28,height:28,borderRadius:"50%",background:color,cursor:"pointer",border:platForm.color===color?"3px solid #fff":"3px solid transparent",transition:"border .15s"}}/>
                ))}
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",background:P.input,borderRadius:10,cursor:"pointer"}} onClick={()=>setPlatForm(f=>({...f,hasProfiles:!f.hasProfiles}))}>
              <div style={{width:36,height:20,background:platForm.hasProfiles?theme.accent:"#252540",borderRadius:10,position:"relative",transition:"background .2s",flexShrink:0}}>
                <div style={{position:"absolute",top:2,left:platForm.hasProfiles?18:2,width:16,height:16,background:"#fff",borderRadius:"50%",transition:"left .2s"}}/>
              </div>
              <div><div style={{fontSize:13,fontWeight:600}}>Soporta perfiles</div><div style={{fontSize:11,color:P.textMuted}}>Netflix, Disney+, etc.</div></div>
            </div>
            <div style={{display:"flex",gap:10,marginTop:4}}>
              <button onClick={()=>setShowPlat(false)} style={{flex:1,padding:11,background:P.input,border:"none",borderRadius:10,cursor:"pointer",color:P.textMuted,fontWeight:600}}>Cancelar</button>
              <button onClick={handleSavePlat} style={{flex:2,padding:11,background:theme.grad,border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>Guardar plataforma</button>
            </div>
          </div>
        </div>
      </div>
    )}

    {/* ══ MODAL PAGO ══ */}
    {showPago&&(
      <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowPago(false)}>
        <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,padding:22,width:"min(420px,96vw)"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:16}}>
            <h3 style={{fontSize:16,fontWeight:800}}>{editPagoId?"Editar Pago":"Nuevo Pago"}</h3>
            <button onClick={()=>setShowPago(false)} style={{background:"none",border:"none",color:P.textMuted,fontSize:20,cursor:"pointer"}}>✕</button>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <div>
              <label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Cuenta *</label>
              <select className="ifield" value={pagoForm.ventaId} onChange={e=>setPagoForm({...pagoForm,ventaId:e.target.value})}>
                <option value="">Seleccionar cuenta…</option>
                {ventas.map(v=><option key={v.id} value={v.id}>{v.cliente} – {platOf(v.plataforma,customPlats).name}</option>)}
              </select>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 90px",gap:10}}>
              <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Monto *</label><input className="ifield" type="number" placeholder="0.00" value={pagoForm.monto} onChange={e=>setPagoForm({...pagoForm,monto:e.target.value})}/></div>
              <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Moneda</label><select className="ifield" value={pagoForm.moneda} onChange={e=>setPagoForm({...pagoForm,moneda:e.target.value})}>{CURRENCIES.map(c=><option key={c}>{c}</option>)}</select></div>
            </div>
            <div>
              <label style={{fontSize:12,color:P.textMuted,marginBottom:6,display:"block",fontWeight:700}}>Estado</label>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                {[{id:"pendiente",label:"⏳ Pendiente",c:"#ff9f0a"},{id:"parcial",label:"⚡ Parcial",c:"#ffd60a"},{id:"pagado",label:"✅ Pagado",c:"#30d158"}].map(s=>(
                  <button key={s.id} onClick={()=>setPagoForm({...pagoForm,estado:s.id})} style={{padding:"9px 4px",borderRadius:9,border:`2px solid ${pagoForm.estado===s.id?s.c:P.border}`,background:pagoForm.estado===s.id?s.c+"22":P.input,color:pagoForm.estado===s.id?s.c:P.textMuted,fontWeight:700,fontSize:12,cursor:"pointer"}}>{s.label}</button>
                ))}
              </div>
            </div>
            <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Fecha</label><input className="ifield" type="date" value={pagoForm.fecha} onChange={e=>setPagoForm({...pagoForm,fecha:e.target.value})}/></div>
            <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Notas</label><textarea className="ifield" placeholder="Opcional…" value={pagoForm.notas} onChange={e=>setPagoForm({...pagoForm,notas:e.target.value})} rows={2} style={{resize:"vertical"}}/></div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setShowPago(false)} style={{flex:1,padding:11,background:P.input,border:"none",borderRadius:10,cursor:"pointer",color:P.textMuted,fontWeight:600}}>Cancelar</button>
              <button onClick={handleSavePago} style={{flex:2,padding:11,background:theme.grad,border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>Guardar pago</button>
            </div>
          </div>
        </div>
      </div>
    )}

    {/* ══ MODAL RECORDATORIO ══ */}
    {showRec&&(
      <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowRec(false)}>
        <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:18,padding:22,width:"min(420px,96vw)"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:16}}>
            <h3 style={{fontSize:16,fontWeight:800}}>{editRecId?"Editar Recordatorio":"Nuevo Recordatorio"}</h3>
            <button onClick={()=>setShowRec(false)} style={{background:"none",border:"none",color:P.textMuted,fontSize:20,cursor:"pointer"}}>✕</button>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <div>
              <label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Cuenta *</label>
              <select className="ifield" value={recForm.ventaId} onChange={e=>setRecForm({...recForm,ventaId:e.target.value})}>
                <option value="">Seleccionar cuenta…</option>
                {ventas.map(v=><option key={v.id} value={v.id}>{v.cliente} – {platOf(v.plataforma,customPlats).name} ({fmtDate(v.fechaVence)})</option>)}
              </select>
            </div>
            <div>
              <label style={{fontSize:12,color:P.textMuted,marginBottom:6,display:"block",fontWeight:700}}>Avisar cuando falten (días)</label>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:7}}>
                {[1,3,5,7].map(d=>(
                  <button key={d} onClick={()=>setRecForm({...recForm,diasAntes:d})} style={{padding:"9px 4px",borderRadius:9,border:`2px solid ${recForm.diasAntes===d?theme.accent:P.border}`,background:recForm.diasAntes===d?theme.accent+"22":P.input,color:recForm.diasAntes===d?theme.accent:P.textMuted,fontWeight:700,fontSize:13,cursor:"pointer"}}>{d}d</button>
                ))}
              </div>
            </div>
            <div><label style={{fontSize:12,color:P.textMuted,marginBottom:4,display:"block",fontWeight:700}}>Nota interna (opcional)</label><input className="ifield" placeholder="Ej: Cliente difícil, llamar primero" value={recForm.mensaje} onChange={e=>setRecForm({...recForm,mensaje:e.target.value})}/></div>
            <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",background:P.input,borderRadius:10,cursor:"pointer"}} onClick={()=>setRecForm(r=>({...r,activo:!r.activo}))}>
              <div style={{width:36,height:20,background:recForm.activo?theme.accent:"#252540",borderRadius:10,position:"relative",transition:"background .2s",flexShrink:0}}>
                <div style={{position:"absolute",top:2,left:recForm.activo?18:2,width:16,height:16,background:"#fff",borderRadius:"50%",transition:"left .2s"}}/>
              </div>
              <span style={{fontSize:13,fontWeight:600}}>Recordatorio activo</span>
            </div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setShowRec(false)} style={{flex:1,padding:11,background:P.input,border:"none",borderRadius:10,cursor:"pointer",color:P.textMuted,fontWeight:600}}>Cancelar</button>
              <button onClick={handleSaveRec} style={{flex:2,padding:11,background:theme.grad,border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>Guardar recordatorio</button>
            </div>
          </div>
        </div>
      </div>
    )}

        {/* Confirmar eliminar */}
    {delId&&(
      <div className="overlay">
        <div style={{background:P.card,border:`1px solid ${P.border}`,borderRadius:16,padding:24,width:"min(310px,92vw)",textAlign:"center"}}>
          <div style={{fontSize:32,marginBottom:10}}>🗑️</div>
          <div style={{fontWeight:800,fontSize:15,marginBottom:7}}>¿Eliminar cuenta?</div>
          <div style={{color:"#44445a",fontSize:13,marginBottom:20}}>Se eliminará con perfiles e historial.</div>
          <div style={{display:"flex",gap:10}}>
            <button onClick={()=>setDelId(null)} style={{flex:1,padding:11,background:"#181828",border:"none",borderRadius:10,cursor:"pointer",color:"#888",fontWeight:600}}>Cancelar</button>
            <button onClick={()=>handleDeleteVenta(delId)} style={{flex:1,padding:11,background:"#ff2d55",border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontWeight:700}}>Eliminar</button>
          </div>
        </div>
      </div>
    )}

    {/* Toast */}
    {toast&&(
      <div className="toast" style={{borderColor:toast.color}}>
        <div style={{width:8,height:8,borderRadius:"50%",background:toast.color}}/>
        <span style={{fontSize:13,fontWeight:600,color:toast.color}}>{toast.msg}</span>
      </div>
    )}
    </div>
  );
}
